"use strict";
var PANEL = "https://fenix-tv-studio-panel.elmanuchale.workers.dev"; // URL del Worker (sin "/" final)
var $ = function (s) { return document.querySelector(s); };
// Mientras corre la intro (body.ip) no se procesa el catálogo: parsear el JSON y dibujar la rejilla en el TV le quita ciclos a la animación y la desfasa del sonido.
// La descarga sí empieza de inmediato (red); solo se espera para leer y pintar. introGate(v) devuelve una promesa que se cumple al terminar la intro.
var INTRO = { done: !document.getElementById("intro"), q: [] };
function introGate(v) { return new Promise(function (res) { if (INTRO.done) res(v); else INTRO.q.push(function () { res(v); }); }); }
var esc = function (s) { return String(s == null ? "" : s).replace(/[&<>"]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]; }); };
var lc = function (o) { var r = {}; for (var k in o) r[k.toLowerCase()] = o[k]; return r; };
var norm = function (s) { return String(s || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, ""); };
var on = function (e) { return e.enabled !== false; };
var pad = function (n) { return (n < 10 ? "0" : "") + n; };
var sz = function (u, s) { return u && u.indexOf("image.tmdb.org/t/p/") > -1 ? u.replace(/\/t\/p\/(original|w\d+)\//, "/t/p/" + s + "/") : u || ""; };
var ft = function (s) { s = Math.max(0, s | 0); var h = s / 3600 | 0, m = s % 3600 / 60 | 0; return (h ? h + ":" + pad(m) : m) + ":" + pad(s % 60); };
var mins = function (s) { var m = Math.max(1, Math.round(s / 60)); return m >= 60 ? (m / 60 | 0) + " h" + (m % 60 ? " " + m % 60 + " min" : "") : m + " min"; };
var S = { tab: "movie", cat: "Todas", vod: null, tv: [], items: [], layers: [], foc: [], sq: "", ss: "all", cache: {}, fl: 0, fr: 0, lastC: null };
var E_APP = $("#app"), E_SIDE = $("#side"), E_MAIN = $("#main"), E_GRID = $("#grid");
var ckey = function () { return "fenixcont_" + (S.me ? S.me.id : "x"); }; // historial separado por perfil
var store = {
  get: function () { try { return JSON.parse(localStorage.getItem(ckey()) || "[]"); } catch (e) { return []; } },
  set: function (l) { try { localStorage.setItem(ckey(), JSON.stringify(l.slice(0, 30))); } catch (e) { } }
};
var TABS = [["movie", "Películas"], ["series", "Series"], ["tv", "TV"]]; // "Continuar viendo" ya no es sección del menú: vive como primera fila en Películas y Series

// ---------- Novedades: insignia "NUEVO" y fila "Recién agregado" ----------
// Por perfil se guarda qué títulos ya conocía el catálogo y cuándo apareció cada uno por primera vez.
// "NUEVO" = apareció después de tu visita anterior (máx. 14 días) y todavía no lo abriste.
// La primera vez que se usa un perfil solo se toma la foto del catálogo: nada se marca como nuevo.
var NW_DAY = 864e5, NW_RECENT = 14 * NW_DAY, NW_VISIT = 30 * 60 * 1000; // una "visita" nueva = abrir la app pasados 30 min de la anterior
function addedTs(e) { // fecha de alta que traiga el panel (opcional): milisegundos, segundos o texto de fecha
  var names = ["added", "addedat", "dateadded", "agregado", "fechaagregado"], i, v, t;
  for (i = 0; i < names.length; i++) {
    v = e[names[i]]; if (v == null || v === "" || typeof v === "boolean") continue;
    t = typeof v === "number" ? v : /^\d+$/.test(String(v).trim()) ? +v : Date.parse(v);
    if (t > 0 && t < 1e11) t *= 1000;
    if (t > 1e11) return t;
  }
  return 0;
}
var nw = {
  key: function () { return "fenixseen_" + (S.me ? S.me.id : "x"); },
  save: function () { try { localStorage.setItem(nw.k, JSON.stringify(nw.st)); } catch (e) { } },
  sync: function () { // carga el registro del perfil y anota los títulos que aún no conocía; sin perfil elegido no hace nada
    if (!S.me || !S.vod) return null;
    var key = nw.key(); if (nw.st && nw.k === key && nw.v === S.vod) return nw.st;
    var now = Date.now(), st = null, first, all, live = {}, k;
    try { st = JSON.parse(localStorage.getItem(key) || "null"); } catch (e) { }
    if (!st || typeof st !== "object" || !st.known) st = null;
    first = !st;
    if (first) st = { known: {}, seen: {}, prev: 0, cur: now };
    else { st.seen = st.seen || {}; st.prev = +st.prev || 0; if (now - (+st.cur || 0) > NW_VISIT) { st.prev = +st.cur || 0; } st.cur = now; }
    all = recs("movie").concat(recs("series"));
    all.forEach(function (r) { k = r.kind + "|" + r.id; live[k] = 1; if (st.known[k] == null) st.known[k] = first ? 0 : now; });
    if (all.length) { // con el catálogo vacío (falla del panel) no se poda nada
      for (k in st.known) if (!live[k] && st.known[k] > 0 && st.known[k] < now - 90 * NW_DAY) delete st.known[k];
      for (k in st.seen) if (!(st.known[k] > st.prev)) delete st.seen[k];
    }
    nw.st = st; nw.k = key; nw.v = S.vod;
    if (all.length) nw.save();
    return st;
  },
  ts: function (r, st) { return r.added > 0 ? r.added : st.known[r.kind + "|" + r.id] || 0; },
  isNew: function (r) {
    var st = nw.sync(); if (!st) return false;
    return nw.ts(r, st) > Math.max(st.prev, Date.now() - NW_RECENT) && !st.seen[r.kind + "|" + r.id];
  },
  seen: function (r) { // al abrir o reproducir un título, deja de ser "NUEVO" (también en las tarjetas que ya están en pantalla)
    if (!r || !r.kind || !nw.isNew(r)) return;
    var k = r.kind + "|" + r.id; nw.st.seen[k] = 1; nw.save();
    [].forEach.call(document.querySelectorAll(".tag.nw"), function (t) { if (t.dataset.nk === k) t.remove(); });
  },
  recent: function (list) { // los más recientes primero, hasta 14 días atrás
    var st = nw.sync(); if (!st) return [];
    var cut = Date.now() - NW_RECENT;
    return list.map(function (r) { return { r: r, t: nw.ts(r, st) }; }).filter(function (x) { return x.t > cut; })
      .sort(function (a, b) { return b.t - a.t || b.r.order - a.r.order; }).slice(0, ROWCAP).map(function (x) { return x.r; });
  }
};
function nwTag(r) { return r && r.kind && r.id != null && nw.isNew(r) ? '<i class="tag nw" data-nk="' + esc(r.kind + "|" + r.id) + '">NUEVO</i>' : ""; }

// ---------- Puntuación: se toma sola de lo que traiga el panel y, si falta, se busca en TMDB (opcional) ----------
var TMDB_KEY = ""; // opcional: clave de themoviedb.org (v3 de 32 caracteres, o token v4) para completar solas las puntuaciones que el panel no traiga
var RT_FIELDS = ["imdbrating", "imdb", "rating", "tmdbrating", "voteaverage", "score", "puntuacion", "calificacion", "valoracion"]; // los dos primeros se rotulan "IMDb"
function parseScore(v) { // acepta 7.5, "7,5", "7.5/10", "3.8/5", "75%" o 0-100 → número de 0 a 10 (0 = sin puntuación)
  if (v == null || v === "" || typeof v === "boolean") return 0;
  var s = String(v).replace(",", "."), m = /\d+(\.\d+)?/.exec(s), n = m ? parseFloat(m[0]) : 0;
  if (!(n > 0)) return 0;
  if (/\/\s*5(\.0+)?\s*$/.test(s)) n *= 2; else if (/%/.test(s) || n > 10) n /= 10;
  return n > 0 && n <= 10 ? n : 0;
}
var rt = {
  m: null,
  load: function () { if (!rt.m) { try { rt.m = JSON.parse(localStorage.getItem("fenixrate") || "{}") || {}; } catch (e) { rt.m = {}; } } return rt.m; },
  save: function () { try { localStorage.setItem("fenixrate", JSON.stringify(rt.m || {})); } catch (e) { } },
  lookup: function (r) { // puntuación de TMDB para un título (0 = no tiene); rechaza si la clave falla o hay límite de uso
    var tv = r.kind === "series", y = r.pyear || +r.year || 0, bearer = TMDB_KEY.length > 40;
    var go = function (withYear) {
      var u = "https://api.themoviedb.org/3/search/" + (tv ? "tv" : "movie") + "?query=" + encodeURIComponent(r.title) + (bearer ? "" : "&api_key=" + encodeURIComponent(TMDB_KEY)) + (withYear && y ? "&" + (tv ? "first_air_date_year=" : "year=") + y : "");
      return fetch(u, bearer ? { headers: { Authorization: "Bearer " + TMDB_KEY } } : undefined).then(function (x) {
        if (x.status === 401 || x.status === 429) { var er = new Error("tmdb " + x.status); er.fatal = true; throw er; }
        if (!x.ok) throw new Error("tmdb " + x.status);
        return x.json();
      }).then(function (j) {
        var l = ((j && j.results) || []).filter(function (z) { return z.vote_count > 0 && z.vote_average > 0; });
        if (!withYear) l = l.filter(function (z) { return norm(z.title || z.name) === norm(r.title); }); // sin año solo vale el título exacto
        if (!l.length && withYear && y) return go(false);
        return l.length ? l[0].vote_average : 0;
      });
    };
    return go(true);
  },
  fill: function () { // completa las que faltan, de 3 en 3, y las recuerda 30 días (también las que no tienen) para no repetir la búsqueda
    if (!TMDB_KEY || !S.vod || rt.busy) return;
    var m = rt.load(), now = Date.now(), todo = [], left = 3, dirty = 0, stop = false;
    recs("movie").concat(recs("series")).forEach(function (r) { var c = m[r.kind + "|" + r.id]; if (!r.rating && r.title && !(c && now - c.t < 30 * NW_DAY)) todo.push(r); });
    todo = todo.slice(0, 400); if (!todo.length) return;
    rt.busy = true;
    var next = function () {
      var r = todo.shift();
      if (!r || stop) { if (--left === 0) { if (dirty) rt.save(); rt.busy = false; } return; }
      rt.lookup(r).then(function (v) {
        m[r.kind + "|" + r.id] = { v: v, t: Date.now() }; dirty++;
        if (v > 0 && !r.rating) { r.rating = v.toFixed(1); r.rsrc = "tmdb"; paintRating(r); }
        if (dirty % 10 === 0) rt.save();
      }).catch(function (e) { if (e && e.fatal) stop = true; }).then(next);
    };
    next(); next(); next();
  }
};
function ratingOf(e, ck) { // { v: "7.5", s: "imdb" | "tmdb" | "" }
  var k = {}, n, i, v, c;
  for (n in e) k[n.replace(/[_\- ]/g, "")] = e[n];
  for (i = 0; i < RT_FIELDS.length; i++) { v = parseScore(k[RT_FIELDS[i]]); if (v) return { v: v.toFixed(1), s: i < 2 ? "imdb" : "" }; }
  c = ck && rt.load()[ck]; return c && c.v > 0 ? { v: c.v.toFixed(1), s: "tmdb" } : { v: "", s: "" };
}
function rlabel(r) { return r.rating ? "★ " + (r.rsrc === "imdb" ? "IMDb " : r.rsrc === "tmdb" ? "TMDB " : "") + r.rating : ""; }
function ratingTag(r) { return r && r.rating ? '<i class="tag rt">★ ' + r.rating + "</i>" : ""; }
function paintRating(r) { // la puntuación llegó con las tarjetas ya en pantalla: se agrega sin volver a dibujar la lista
  var k = r.kind + "|" + r.id;
  [].forEach.call(document.querySelectorAll(".card[data-rk]"), function (c) {
    if (c.dataset.rk !== k || c.querySelector(".tag.rt")) return;
    var ph = c.querySelector(".ph"); if (ph) ph.insertAdjacentHTML("beforeend", ratingTag(r));
  });
}

// ---------- Perfil (nombre + avatar, se guarda en el televisor) ----------
// Avatares originales dibujados en SVG plano (sin ids ni degradados internos, el fondo es CSS).
var AV = [
  { id: "zorro", n: "Zorro", bg: "linear-gradient(135deg,#1F2B6B,#4F8CFF)", s: '<svg viewBox="0 0 100 100"><path fill="#FF8A3D" d="M14 10L47 32L15 54Z"/><path fill="#FF8A3D" d="M86 10L53 32L85 54Z"/><path fill="#7A2E10" d="M21 23L37 33L21 44Z"/><path fill="#7A2E10" d="M79 23L63 33L79 44Z"/><path fill="#FF8A3D" d="M12 52Q12 32 50 30Q88 32 88 52Q88 74 62 90Q50 96 38 90Q12 74 12 52Z"/><path fill="#FFF3E6" d="M12 58Q30 62 50 76Q70 62 88 58Q86 76 62 90Q50 96 38 90Q14 76 12 58Z"/><path fill="#FFB36B" d="M50 32L57 44L50 53L43 44Z"/><ellipse cx="34" cy="55" rx="4" ry="5.2" fill="#2B1B14"/><ellipse cx="66" cy="55" rx="4" ry="5.2" fill="#2B1B14"/><circle cx="35.6" cy="53" r="1.5" fill="#fff"/><circle cx="67.6" cy="53" r="1.5" fill="#fff"/><path fill="#2B1B14" d="M43 77Q50 73 57 77Q54 84 50 85Q46 84 43 77Z"/></svg>' },
  { id: "astro", n: "Astro", bg: "linear-gradient(135deg,#3B2A8A,#8B5CF6)", s: '<svg viewBox="0 0 100 100"><path fill="#DDE2F5" d="M8 100Q12 82 50 82Q88 82 92 100Z"/><path d="M50 22L50 11" stroke="#C7CFEA" stroke-width="3.5" stroke-linecap="round"/><circle cx="50" cy="9" r="4" fill="#E5484D"/><rect x="9" y="44" width="9" height="16" rx="3.5" fill="#FFC857"/><rect x="82" y="44" width="9" height="16" rx="3.5" fill="#FFC857"/><circle cx="50" cy="54" r="33" fill="#F4F6FF"/><path fill="#D5DBF2" d="M50 87A33 33 0 0 0 83 54Q70 76 50 76Z"/><rect x="22" y="38" width="56" height="34" rx="17" fill="#141A44"/><path d="M29 47Q35 41 45 41" stroke="#7FA8FF" stroke-width="3" fill="none" stroke-linecap="round"/><circle cx="40" cy="56" r="3.6" fill="#9DE4FF"/><circle cx="60" cy="56" r="3.6" fill="#9DE4FF"/><path d="M44 63Q50 67 56 63" stroke="#9DE4FF" stroke-width="2.6" fill="none" stroke-linecap="round"/><circle cx="70" cy="45" r="2" fill="#FFC857"/></svg>' },
  { id: "robo", n: "Robo", bg: "linear-gradient(135deg,#0B4A5A,#2EC4B6)", s: '<svg viewBox="0 0 100 100"><path d="M50 28L50 15" stroke="#8E94B0" stroke-width="4" stroke-linecap="round"/><circle cx="50" cy="12" r="5.5" fill="#FFC857"/><rect x="9" y="48" width="11" height="22" rx="4.5" fill="#8E94B0"/><rect x="80" y="48" width="11" height="22" rx="4.5" fill="#8E94B0"/><path fill="#B3BBDA" d="M12 100Q16 88 50 88Q84 88 88 100Z"/><rect x="36" y="80" width="28" height="10" fill="#8E94B0"/><rect x="18" y="26" width="64" height="58" rx="15" fill="#D5DCF5"/><rect x="26" y="36" width="48" height="38" rx="11" fill="#10163A"/><rect x="35" y="46" width="9" height="13" rx="4.5" fill="#5CE1FF"/><rect x="56" y="46" width="9" height="13" rx="4.5" fill="#5CE1FF"/><path d="M41 66Q50 72 59 66" stroke="#5CE1FF" stroke-width="3" fill="none" stroke-linecap="round"/><circle cx="23" cy="79" r="1.8" fill="#8E94B0"/><circle cx="77" cy="79" r="1.8" fill="#8E94B0"/></svg>' },
  { id: "buho", n: "Búho", bg: "linear-gradient(135deg,#7A1F5C,#FF6FA5)", s: '<svg viewBox="0 0 100 100"><path fill="#6B4430" d="M16 10L44 30L14 46Z"/><path fill="#6B4430" d="M84 10L56 30L86 46Z"/><ellipse cx="50" cy="58" rx="40" ry="38" fill="#8A5A3C"/><circle cx="34" cy="50" r="18" fill="#F3DFC1"/><circle cx="66" cy="50" r="18" fill="#F3DFC1"/><circle cx="34" cy="50" r="11" fill="#fff"/><circle cx="66" cy="50" r="11" fill="#fff"/><circle cx="34" cy="51" r="6.5" fill="#1B1020"/><circle cx="66" cy="51" r="6.5" fill="#1B1020"/><circle cx="36.4" cy="48.5" r="2.2" fill="#fff"/><circle cx="68.4" cy="48.5" r="2.2" fill="#fff"/><path d="M21 33Q33 26 44 34M79 33Q67 26 56 34" stroke="#5A3826" stroke-width="3.6" fill="none" stroke-linecap="round"/><path fill="#FFC857" d="M43 58L57 58L50 71Z"/><path d="M30 84Q35 91 40 84M45 88Q50 95 55 88M60 84Q65 91 70 84" stroke="#C8946B" stroke-width="3" fill="none" stroke-linecap="round"/></svg>' }
];
var PMAX = 5;
var prof = {
  all: function () {
    var l = null, ok = function (p) { return p && typeof p.n === "string" && p.n.trim() && p.id; };
    try { l = JSON.parse(localStorage.getItem("fenixprofiles") || "null"); } catch (e) { }
    if (Array.isArray(l)) return l.filter(ok).slice(0, PMAX);
    try { // migración: perfil único de la 1.0.5 → primer perfil de la lista, conservando su historial
      var o = JSON.parse(localStorage.getItem("fenixprofile") || "null");
      if (o && typeof o.n === "string" && o.n.trim()) {
        var p = { id: "p1", n: o.n, a: o.a }, old = localStorage.getItem("fenixcont");
        if (old && !localStorage.getItem("fenixcont_p1")) localStorage.setItem("fenixcont_p1", old);
        localStorage.setItem("fenixprofiles", JSON.stringify([p])); localStorage.setItem("fenixactive", "p1"); return [p];
      }
    } catch (e) { }
    return [];
  },
  save: function (l) { try { localStorage.setItem("fenixprofiles", JSON.stringify(l)); } catch (e) { } },
  last: function () { try { return localStorage.getItem("fenixactive") || ""; } catch (e) { return ""; } },
  setLast: function (id) { try { localStorage.setItem("fenixactive", id); } catch (e) { } },
  newId: function () { return "p" + Date.now().toString(36) + Math.floor(Math.random() * 1296).toString(36); }
};
var PEN = '<svg viewBox="0 0 24 24"><path d="M4 20L5 15L15.5 4.5L19.5 8.5L9 19Z" fill="#3A2A00"/></svg>';
var PLUS = '<svg viewBox="0 0 100 100"><path d="M50 30V70M30 50H70" stroke="#8E94B0" stroke-width="7" stroke-linecap="round"/></svg>';
var CHECK = '<svg viewBox="0 0 24 24"><path d="M5 12.5L10 17.5L19 7" stroke="#3A2A00" stroke-width="3.4" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>';
function avOf(id) { for (var i = 0; i < AV.length; i++) if (AV[i].id === id) return AV[i]; return AV[0]; }
function avHtml(a, cls) { return '<span class="' + cls + '" style="background:' + a.bg + '">' + a.s + "</span>"; }
S.ps = prof.all(); S.me = S.ps.length === 1 ? S.ps[0] : null; S.pick = null; S.first = false; S.wm = ""; S.manage = false;
var io = new IntersectionObserver(function (es) {
  es.forEach(function (x) { if (x.isIntersecting) { var i = x.target; if (i.dataset.s) ldImg(i); io.unobserve(i); } });
}, { rootMargin: "700px" });

// ---------- Datos ----------
function sec(v) { if (v == null || v === "") return -1; v = String(v).trim(); if (!/^[\d.]/.test(v)) return -1; return v.split(":").reduce(function (a, p) { return a * 60 + parseFloat(p); }, 0); }
function markers(o) {
  var k = {};
  (function walk(x) {
    for (var n in x) { var key = n.toLowerCase().replace(/[_\- ]/g, ""), v = x[n]; if (v && typeof v === "object" && !Array.isArray(v) && /^(markers|skips?|timestamps)$/.test(key)) walk(v); else if (k[key] == null) k[key] = v; }
  })(o);
  var f = function () { for (var i = 0; i < arguments.length; i++) if (k[arguments[i]] != null) { var r = sec(k[arguments[i]]); if (r >= 0) return r; } return -1; };
  var m = { is: f("introstartseconds", "introstart"), ie: f("introendseconds", "introend"), nx: f("creditsstartseconds", "creditsstart", "outrostart", "nextat") };
  if (m.ie < 0 && k.intro && typeof k.intro === "object") { var it = lc(k.intro); m.is = Math.max(0, sec(it.start)); m.ie = sec(it.end); }
  if (m.ie >= 0 && m.is < 0) m.is = 0;
  return m;
}
function recs(kind) {
  if (S.cache[kind]) return S.cache[kind];
  var src = (S.vod && (kind === "movie" ? S.vod.movies : S.vod.series)) || [], yr = new Date().getFullYear(), out = [];
  src.forEach(function (raw, i) {
    var e = lc(raw); if (!on(e)) return;
    if (kind === "movie" ? !e.url : !(e.episodes && e.episodes.length)) return;
    var img = e.logo || e.hdposterurl || e.landscape || "", y = /(19|20)\d\d/.exec(String(e.releasedate || e.released || e.premieredate || e.estreno || e.releaseyear || e.year || ""));
    var forced = /^(true|1|yes|si|sí)$/i.test(String(e.premiere || e.estreno || e.isnew || e.nuevo || "")), rid = e.id != null ? String(e.id) : norm(e.title), ro = ratingOf(e, kind + "|" + rid);
    out.push({
      kind: kind, e: e, raw: raw, order: i, id: e.id != null ? String(e.id) : norm(e.title), title: e.title || "", poster: sz(img, "w342"), big: sz(img, "w500"),
      back: sz(e.backdrop || e.landscape || "", "w1280"), plot: e.description || "", genre: e.genre || e.section || "Otros", year: String(e.year || ""),
      rating: ro.v, rsrc: ro.s, prem: forced || (y && +y[0] >= yr - 1), pyear: y ? +y[0] : 0, added: addedTs(e)
    });
  });
  return (S.cache[kind] = out);
}
function eplist(r) { // todos los capítulos activos ordenados por temporada y número
  if (r.eps) return r.eps;
  var l = [];
  (r.e.episodes || []).forEach(function (x) {
    x = lc(x); if (!on(x) || !x.url) return;
    l.push({ sn: parseInt(x.season) > 0 ? parseInt(x.season) : 1, en: parseInt(x.episode) || 0, title: x.title || "", url: x.url, rt: x.runtime || "", desc: x.description || "", mk: markers(x), alts: altList(x), subs: subList(x) });
  });
  var c = {}; l.forEach(function (x) { c[x.sn] = (c[x.sn] || 0) + 1; if (!x.en) x.en = c[x.sn]; });
  l.sort(function (a, b) { return a.sn - b.sn || a.en - b.en; });
  return (r.eps = l);
}
function parseTv(conf) {
  var out = [], ch = conf && conf.channels || {};
  Object.keys(ch).forEach(function (key) {
    var c = ch[key]; if (!c || !on(c)) return;
    var progs = [], total = 0, spare = null;
    (c.programs || []).forEach(function (p) {
      if (!p || !on(p) || !p.url) return;
      var d = Math.floor(+p.durationSeconds) || 0, it = { title: p.title || "", url: p.url, dur: d, alts: altList(lc(p)) };
      if (d > 0) { progs.push(it); total += d; } else if (!spare) spare = it;
    });
    if (!progs.length && spare) progs.push(spare);
    if (progs.length) out.push({ key: key, name: c.name || key, logo: c.logo || "", epoch: Math.floor(+c.epoch) || 0, total: total, progs: progs });
  });
  out.sort(function (a, b) { return a.name.toLowerCase() < b.name.toLowerCase() ? -1 : 1; });
  out.forEach(function (c, i) { c.num = i + 1; });
  return out;
}
function nowPlaying(c) {
  if (c.total <= 0) return { i: 0, off: 0 };
  var t = (Math.floor(Date.now() / 1000) - c.epoch) % c.total; if (t < 0) t += c.total;
  for (var i = 0; i < c.progs.length; i++) { if (t < c.progs[i].dur) return { i: i, off: t }; t -= c.progs[i].dur; }
  return { i: 0, off: 0 };
}
function load() {
  $("#grid").innerHTML = skeleton(14); // esqueletos con brillo en vez del texto "Cargando catálogo…"
  fetch(PANEL + "/vod.json").then(function (r) { if (!r.ok) throw new Error("El panel respondió HTTP " + r.status); return introGate(r).then(function (r2) { return r2.json(); }); }).then(function (j) {
    S.vod = j; S.cache = {};
    return fetch(PANEL + "/channels.json").then(function (r) { return r.ok ? r.json() : null; }).catch(function () { return null; });
  }).then(function (c) { S.tv = parseTv(c); render(); focApp(); try { rt.fill(); } catch (e) { } })
    .catch(function (e) { $("#grid").innerHTML = '<div class="msg">No se pudo cargar el catálogo.<br>' + esc(e.message) + '<br><br><span class="b f" data-a="retry">Reintentar</span></div>'; focApp(); });
}
function focApp() { if (S.layers.indexOf("welcome") < 0 && S.layers.indexOf("who") < 0) focSide(); } // al entrar, el foco empieza en el menú lateral (Películas); ▶ pasa al contenido y el menú se oculta, y solo vuelve con ◀ // no robar el foco en bienvenida / selector de perfil

// ---------- Continuar viendo ----------
function studioLogo(e) { // logo de la productora / estudio que trae el panel (acepta varios nombres de campo)
  var KO = /(productora|studio|estudio|production|company|compania|network|cadena|distribuidora|brand|marca)/, KI = /(logo|img|image|imagen|icon|icono)/;
  var isU = function (v) { return typeof v === "string" && /^(https?:)?\/\/|^data:image/i.test(v.trim()); };
  var pick = function (v, loose) { // url directa, objeto {logo/url/...} o lista
    if (isU(v)) return loose || /\.(png|jpe?g|webp|svg|gif)(\?|#|$)|image\.tmdb\.org/i.test(v) ? v.trim() : "";
    if (Array.isArray(v)) { for (var i = 0; i < v.length; i++) { var a = pick(v[i], loose); if (a) return a; } return ""; }
    if (v && typeof v === "object") { var o = lc(v); return pick(o.logo || o.logourl || o.logopath || o.logo_path || o.image || o.img || o.icon || o.url || o.src, true); }
    return "";
  };
  for (var n in e) {
    var k = n.toLowerCase().replace(/[_\- ]/g, ""); if (k === "logo" || !KO.test(k)) continue;
    var u = pick(e[n], KI.test(k)); if (u) return sz(u, "w185");
  }
  return "";
}
function contItems() {
  var out = [];
  store.get().forEach(function (c) {
    var r = recs(c.kind).filter(function (x) { return x.id === c.k.split("|").slice(1).join("|"); })[0]; if (!r) return;
    var lab = "", pct = c.dur > 0 ? Math.min(100, c.at / c.dur * 100) : 0, sub = c.dur > 0 ? "Quedan " + mins(c.dur - c.at) : "";
    if (c.kind === "series") { lab = "T" + c.sn + " · E" + c.en; sub = "Temp. " + c.sn + " • Cap. " + c.en + (sub ? " • " + sub : ""); }
    out.push({ kind: "cont", rec: r, c: c, title: r.title, poster: r.poster, pct: pct, lab: lab, sub: sub, studio: studioLogo(r.e) });
  });
  return out;
}
function saveProg() {
  var x = P.ctx, v = $("#v"); if (!x || x.live || !x.rec) return;
  var at = v.currentTime || 0, dur = isFinite(v.duration) ? v.duration || 0 : 0, list = store.get(), k = x.rec.kind + "|" + x.rec.id; // 1.0.28: duration = Infinity se guardaba como null y la barra no salía
  list = list.filter(function (c) { return c.k !== k; });
  if (dur > 0 && (at >= dur - 120 || at / dur >= .95)) {
    if (x.rec.kind === "series") { var n = eplist(x.rec)[x.qi + 1]; if (n) list.unshift({ k: k, kind: "series", t: x.rec.title, sn: n.sn, en: n.en, at: 0, dur: 0, ts: Date.now() }); }
  } else if (at >= 60 || x.had) {
    list.unshift({ k: k, kind: x.rec.kind, t: x.rec.title, sn: x.sn || 0, en: x.en || 0, at: Math.floor(at), dur: Math.floor(dur), ts: Date.now() }); x.had = true;
  } else return;
  store.set(list);
}

// ---------- Pantalla principal ----------
function render() {
  clearInterval(S.ht); S.hero = null; S.lastC = null;
  [].forEach.call(document.querySelectorAll("#nav [data-a=tab]"), function (b) { b.classList.toggle("on", b.dataset.v === S.tab); }); // menú lateral: marca la sección activa
  for (var ti = 0; ti < TABS.length; ti++) if (TABS[ti][0] === S.tab) $("#ttl").textContent = TABS[ti][1];
  var items = [], chips = [], cnt = "";
  if (S.tab === "tv") { items = S.tv.map(function (c) { return { kind: "tv", ch: c }; }); cnt = items.length + " canales"; }
  else {
    var l = recs(S.tab), gs = {}; l.forEach(function (r) { gs[r.genre] = 1; });
    var prem = l.filter(function (r) { return r.prem; }).sort(function (a, b) { return b.pyear - a.pyear || b.order - a.order; });
    chips = ["Todas"].concat(prem.length ? ["Estrenos"] : [], Object.keys(gs).sort());
    if (chips.indexOf(S.cat) < 0) S.cat = "Todas";
    items = S.cat === "Estrenos" ? prem : l.filter(function (r) { return S.cat === "Todas" || r.genre === S.cat; });
    items = items.map(function (r) { return { kind: S.tab, rec: r, title: r.title, poster: r.poster }; });
    cnt = items.length + (S.cat === "Estrenos" ? " estrenos" : " títulos");
  }
  var hm = (S.tab === "movie" || S.tab === "series") && S.cat === "Todas" && l.length ? homeView(l, prem) : null; // inicio: banner + filas por género
  if (hm) chips = []; // en el inicio las categorías son las filas, no botones
  S.items = hm ? hm.flat : items; S.main = S.items; S.home = !!hm; S.gall = hm ? null : items; S.gn = Math.min(items.length, GCH0); $("#count").textContent = cnt;
  $("#chips").innerHTML = chips.map(function (c) { return '<button class="b f' + (c === S.cat ? " on" : "") + (c === "Estrenos" ? " gold" : "") + '" data-a="cat" data-v="' + esc(c) + '">' + (c === "Estrenos" ? "★ " : "") + esc(c) + "</button>"; }).join("");
  $("#grid").style.top = chips.length ? "16rem" : "8rem"; $("#grid").innerHTML = (hm ? hm.html : cards(items.slice(0, GCH0), S.tab === "tv", null, 0, { base: 0, step: 45, max: 30 })) || '<div class="msg">' + (S.tab === "tv" ? "No hay canales activos." : "Sin resultados.") + "</div>";
  var g0 = $("#grid"); g0._tscrollTop = 0; g0._ty = null; g0.scrollTop = 0; // cada pestaña/categoría arranca arriba para que la cascada se vea desde el primer póster
  [].forEach.call(g0.querySelectorAll(".rw"), function (w) { rowState(w); }); // flechas del puntero: solo hacia donde la fila aún tiene contenido
  observe("#grid"); if (hm) heroInit(hm.hero);
  S.fl = S.fr = 0; sideAuto(); // lista nueva = arriba del todo: el menú lateral vuelve a mostrarse
}
// Entrada en cascada: an = { base, step, max } (ms de retraso inicial, ms entre tarjetas, cuántas se animan). Sin "an" no hay animación (buscador).
function anim(an, i) {
  if (!an || i >= an.max) return { c: "", s: "" };
  var d = (an.base + i * an.step) + "ms";
  return { c: " cs", s: ' style="-webkit-animation-delay:' + d + ";animation-delay:" + d + '"' };
}
var IMG = ' class="pi" decoding="async" onload="imgOk(this)" onerror="imgBad(this)"'; // los pósters aparecen con fundido al terminar de cargar
function ldImg(i) { var p = i.parentNode; if (p) p.classList.add("ld"); i.src = i.dataset.s; i.removeAttribute("data-s"); } // empieza a cargar: brillo hasta que llegue
function imgOk(i) { var p = i.parentNode; i.classList.add("ok"); if (p) { p.classList.remove("ld"); p.classList.add("ok"); } }
function imgBad(i) { var p = i.parentNode; i.remove(); if (p) p.classList.remove("ld"); }
function skeleton(n) { // rejilla de pósters "fantasma" con brillo mientras llega el catálogo
  var h = "", a;
  for (var i = 0; i < n; i++) { a = anim({ base: 0, step: 40, max: n }, i); h += '<div class="card sk' + a.c + '"' + a.s + '><div class="ph ld"></div><div class="cap"><i class="sb"></i><i class="sb s"></i></div></div>'; }
  return h;
}
function cards(items, tv, tag, off, an) {
  return items.map(function (x, i) {
    var ax = anim(an, i);
    if (x.kind === "tv") {
      var c = x.ch, npx = nowPlaying(c), np = c.progs[npx.i], nxp = c.progs[(npx.i + 1) % c.progs.length], lpc = np.dur > 0 ? Math.min(100, npx.off / np.dur * 100) : 0, hue = 0; for (var j = 0; j < c.name.length; j++) hue = (hue * 31 + c.name.charCodeAt(j)) % 360;
      return '<div class="card ch f' + ax.c + '"' + ax.s + ' tabindex="0" data-a="open" data-i="' + (i + (off | 0)) + '"><div class="ph" style="background:hsl(' + hue + ',40%,22%)"><b>' + c.num + '</b>' + (c.logo ? "<img" + IMG + ' data-s="' + esc(c.logo) + '">' : "") + "<em>" + esc(c.name.split(/\s+/).slice(0, 2).map(function (w) { return w[0]; }).join("").toUpperCase()) + '</em><i class="tag lv">● EN VIVO</i><div class="bar"><i style="width:' + lpc + '%"></i></div></div><div class="cap">' + esc(c.name) + '<small class="ln">Ahora: ' + esc(np.title) + "</small>" + (c.progs.length > 1 ? '<small class="lx">Sigue: ' + esc(nxp.title) + "</small>" : "") + "</div></div>";
    }
    var r = x.rec || {}, t = tag ? tag(x) : "";
    var pic = x.wide || x.poster;
    return '<div class="card f' + (x.wide ? " wd" : "") + (x.rank ? " tn" : "") + (x.kind === "cont" && x.pct > 0 ? " pg" : "") + ax.c + '"' + ax.s + ' tabindex="0" data-a="open"' + (x.kind !== "cont" && r.id != null ? ' data-rk="' + esc(r.kind + "|" + r.id) + '"' : "") + ' data-i="' + (i + (off | 0)) + '">' + (x.rank ? '<b class="bn">' + x.rank + "</b>" : "") + '<div class="ph"><span>' + esc(x.title) + "</span>" + (pic ? "<img" + IMG + ' data-s="' + esc(pic) + '">' : "") + (r.prem ? '<i class="tag">ESTRENO</i>' : "") + nwTag(r) + (x.kind !== "cont" ? ratingTag(r) : "") + (x.lab ? '<i class="tag t">' + x.lab + "</i>" : "") + t + (x.pct ? '<div class="bar"><i style="width:' + x.pct + '%"></i></div>' : "") + (x.studio ? '<div class="stu"><img src="' + esc(x.studio) + '" onerror="this.parentNode.remove()"></div>' : "") + '</div><div class="cap">' + esc(x.title) + "<small>" + esc(x.sub || r.year || "") + "</small></div></div>";
  }).join("");
}
function liveTick() { // canales en vivo: barra de avance y títulos "Ahora / Sigue" al día, sin volver a dibujar la lista
  if (S.tab !== "tv" || S.layers.indexOf("player") > -1) return; // reproduciendo no se toca el DOM de atrás
  [].forEach.call(document.querySelectorAll("#grid .card.ch"), function (el) {
    var x = S.items && S.items[+el.getAttribute("data-i")]; if (!x || !x.ch) return;
    var c = x.ch, n = nowPlaying(c), np = c.progs[n.i], nx = c.progs[(n.i + 1) % c.progs.length];
    var b = el.querySelector(".bar i"), a = el.querySelector(".ln"), z = el.querySelector(".lx");
    if (b) b.style.width = (np.dur > 0 ? Math.min(100, n.off / np.dur * 100) : 0) + "%";
    if (a) a.textContent = "Ahora: " + np.title;
    if (z && c.progs.length > 1) z.textContent = "Sigue: " + nx.title;
  });
}
setInterval(liveTick, 30000);
function observe(sel) { [].forEach.call($(sel).querySelectorAll("img[data-s]"), function (i) { io.observe(i); }); }

// ---------- Inicio: banner destacado + filas por género ----------
var ROWCAP = 30;
function homeView(l, prem) {
  var flat = [], rows = [], by = {}, html = "", hs = [];
  var toItem = function (r) { return { kind: S.tab, rec: r, title: r.title, poster: r.poster }; };
  l.forEach(function (r) { (by[r.genre] = by[r.genre] || []).push(r); });
  var ct = contItems().filter(function (x) { return x.c.kind === S.tab; }); // primera fila: lo que estabas viendo (películas en Películas, series en Series)
  ct.forEach(function (x) { x.wide = sz(x.rec.back, "w780") || x.poster; }); // tarjeta horizontal con la imagen de fondo (si no hay, el póster recortado)
  if (ct.length) rows.push({ name: "Continuar viendo", cont: true, list: ct, items: ct });
  var lastR = null, inCt = {}; // "Porque viste X": mismo género que lo último que viste en esta pestaña
  ct.forEach(function (x) { inCt[x.rec.id] = 1; });
  store.get().some(function (c) {
    if (c.kind !== S.tab) return false;
    lastR = l.filter(function (x) { return x.id === c.k.split("|").slice(1).join("|"); })[0] || null; return !!lastR;
  });
  if (lastR) {
    var sim = l.filter(function (r) { return r.genre === lastR.genre && r.id !== lastR.id && !inCt[r.id]; })
      .sort(function (a, b) { return (parseFloat(b.rating) || 0) - (parseFloat(a.rating) || 0) || b.pyear - a.pyear; }).slice(0, 20);
    if (sim.length >= 4) rows.push({ name: "Porque viste " + lastR.title, list: sim });
  }
  var top = l.filter(function (r) { return parseFloat(r.rating) > 0 && r.poster; })
    .sort(function (a, b) { return parseFloat(b.rating) - parseFloat(a.rating) || b.pyear - a.pyear; }).slice(0, 10);
  if (top.length >= 5) rows.push({ name: "Top 10 · " + (S.tab === "movie" ? "Películas" : "Series"), top: true, list: top,
    items: top.map(function (r, i) { var o = toItem(r); o.rank = i + 1; return o; }) });
  var fresh = nw.recent(l); if (fresh.length) rows.push({ name: "Recién agregado", nw: true, list: fresh });
  if (prem.length) rows.push({ name: "Estrenos", gold: true, list: prem });
  Object.keys(by).sort().forEach(function (g) { rows.push({ name: g, list: by[g] }); });
  rows.forEach(function (w, ri) {
    var part = w.items || w.list.slice(0, ROWCAP).map(toItem), off = flat.length; flat = flat.concat(part);
    html += '<div class="rh' + (w.gold ? " gold" : "") + (w.cont ? " cont" : "") + (w.nw ? " nw" : "") + (w.top ? " top" : "") + '">' + (w.gold ? "★ " : "") + esc(w.name) + "<small>" + w.list.length + '</small></div><div class="rr"><div class="rw">' + cards(part, false, null, off, { base: Math.min(ri, 3) * 140, step: 45, max: 9 }) +
      (w.list.length > ROWCAP ? '<div class="card more f" tabindex="0" data-a="cat" data-v="' + esc(w.name) + '"><div class="ph"><span>Ver todo<br>' + w.list.length + " títulos</span></div></div>" : "") + '</div><i class="ra l" data-a="rowl"></i><i class="ra r" data-a="rowr"></i></div>';
  });
  prem.forEach(function (r) { if (r.back && hs.length < 3) hs.push(r); }); // primero los estrenos, luego los mejor valorados
  l.filter(function (r) { return r.back; }).sort(function (a, b) { return (parseFloat(b.rating) || 0) - (parseFloat(a.rating) || 0); }).forEach(function (r) { if (hs.length < 5 && hs.indexOf(r) < 0) hs.push(r); });
  var hero = hs.length ? '<div id="hero"><div class="hb a"></div><div class="hb b"></div><div class="hs"></div><div class="hc"><div class="hm"></div><div class="ht"></div><div class="hp"></div><div class="hbt"><button class="b f play" id="hpl" data-a="hplay">▶ Reproducir</button><button class="b f" id="hin" data-a="hinfo">Más información</button></div></div><div class="hd"></div></div>' : "";
  return { html: hero + html, flat: flat, hero: hs };
}
function heroInit(hs) {
  clearInterval(S.ht); S.hero = hs; S.hi = -1; if (!hs || !hs.length || !$("#hero")) return;
  $("#hero .hd").innerHTML = hs.length > 1 ? hs.map(function () { return "<span><i></i></span>"; }).join("") : "";
  heroShow(0, true);
  if (hs.length > 1) S.ht = setInterval(heroNext, 8000);
}
function heroNext() {
  if (!$("#hero") || !S.hero || S.hero.length < 2 || S.layers.length || $("#grid").scrollTop > 250) return; // no rota si hay otra pantalla encima o ya bajaste
  heroShow((S.hi + 1) % S.hero.length);
}
function heroShow(n, first) {
  var h = $("#hero"); if (!h) return;
  var r = S.hero[n], tk = S.hk = (S.hk || 0) + 1, hc = h.querySelector(".hc"), ready = !!first, loaded = !!first, im = new Image();
  var apply = function () {
    if (tk !== S.hk || !$("#hero")) return;
    var a = h.querySelector(".hb.a"), b = h.querySelector(".hb.b"), on = a.classList.contains("on"), nx = on ? b : a, pv = on ? a : b, mv = r.kind === "movie";
    nx.style.backgroundImage = "url(" + r.back + ")"; nx.classList.remove("z"); void nx.offsetWidth; nx.classList.add("z"); nx.classList.add("on"); pv.classList.remove("on");
    h.querySelector(".hm").innerHTML = (r.prem ? '<i class="tag">ESTRENO</i>' : "") + nwTag(r) + esc([r.year, r.genre, r.rating && "★ " + r.rating].filter(Boolean).join("  •  "));
    h.querySelector(".ht").textContent = r.title; h.querySelector(".hp").textContent = r.plot;
    $("#hpl").style.display = mv ? "" : "none"; $("#hin").textContent = mv ? "Más información" : "Ver temporadas"; $("#hin").classList.toggle("play", !mv);
    [].forEach.call(h.querySelectorAll(".hd span"), function (d, i) { d.classList.toggle("on", i === n); });
    S.hi = n; hc.classList.remove("fo");
  };
  if (first) return apply();
  hc.classList.add("fo");
  var fin = function () { if (ready && loaded) apply(); };
  setTimeout(function () { ready = true; fin(); }, 330);
  im.onload = im.onerror = function () { loaded = true; fin(); }; im.src = r.back; // espera a que cargue la imagen para no mostrar un hueco
}
function tween(p, prop, from, to) { // 1.0.30: desplazamiento suave de scrollLeft (filas) o scrollTop (lista). La posición "persigue" a la meta en cada cuadro; si llegan pulsaciones seguidas (mantener la flecha) solo cambia la meta, así el movimiento no se reinicia ni da tirones
  var tk = "_t" + prop, rk = "_r" + prop, tau = prop === "scrollTop" ? 55 : 45, last = Date.now(), stuck = 0;
  p[tk] = to;
  if (S.inst) { p[prop] = to; if (prop === "scrollLeft") p._tx = null; else p._ty = null; return; } // 1.0.31: colocar sin animación (volver al mismo sitio)
  if (p[rk]) return;
  p[rk] = true;
  (function step() {
    var now = Date.now(), dt = Math.min(50, Math.max(1, now - last)), tg = p[tk], cur = p[prop], d = tg - cur, st;
    last = now;
    if (Math.abs(d) <= 1 || stuck > 3) { if (Math.abs(d) <= 1) p[prop] = tg; p[rk] = false; if (prop === "scrollLeft") p._tx = null; else p._ty = null; return; }
    st = d * (1 - Math.exp(-dt / tau)); if (Math.abs(st) < 1) st = d > 0 ? 1 : -1;
    p[prop] = cur + st;
    if (Math.abs(p[prop] - cur) < .5) stuck++; else stuck = 0; // si el contenedor no se deja mover (cambió su tamaño), no se queda dando vueltas
    requestAnimationFrame(step);
  })();
}
function colScroll(p, e, m) { // scroll vertical del inicio: la fila entra con su título y el banner vuelve a verse completo al subir
  var pr = p.getBoundingClientRect(), cur = p.scrollTop, base = p._ty != null ? p._ty : cur, vh = p.clientHeight, t = base;
  var rw = e.closest(".rr"), ref = rw && rw.previousSibling && rw.previousSibling.className.indexOf("rh") > -1 ? rw.previousSibling : e;
  var er = e.getBoundingClientRect(), rt = ref.getBoundingClientRect().top - pr.top + cur, eb = er.bottom - pr.top + cur;
  if (e.closest("#hero")) t = 0; else if (eb > base + vh - m) t = eb - vh + m; else if (rt < base + m) t = rt - m;
  t = Math.max(0, Math.min(t, p.scrollHeight - vh)); if (Math.abs(t - base) < 1) return;
  p._ty = t; tween(p, "scrollTop", cur, t);
}
function rowScroll(p, e, m) {
  var pr = p.getBoundingClientRect(), er = e.getBoundingClientRect(), cur = p.scrollLeft, base = p._tx != null ? p._tx : cur, vw = p.clientWidth;
  var offL = er.left - pr.left + cur, t = base, n = e, i, im;
  for (i = 0; i < 6 && n; i++, n = n.nextSibling) { im = n.querySelector && n.querySelector("img[data-s]"); if (im) ldImg(im); } // precarga los pósters que vienen
  if (offL + er.width > base + vw - m) t = offL + er.width - vw + m; else if (offL < base + m) t = offL - m;
  t = Math.max(0, Math.min(t, p.scrollWidth - vw)); if (Math.abs(t - base) < 1) return;
  p._tx = t; tween(p, "scrollLeft", cur, t);
}

// ---------- Capas ----------
function openLayer(id) { S.foc.push(document.activeElement); S.layers.push(id); $("#" + id).classList.add("show"); }
function closeLayer() {
  var id = S.layers.pop(); if (!id) return false;
  if (id === "search" && S.main) S.items = S.main; // la búsqueda pisa S.items: se restaura para que las tarjetas abran el título correcto
  if (id === "player") { document.body.classList.remove("pl"); saveProg(); stopPlayer(); S.seen = true; }
  $("#" + id).classList.remove("show"); var f = S.foc.pop();
  if (S.seen && !S.layers.length && (S.tab === "movie" || S.tab === "series") && S.cat === "Todas") { // volviste al inicio tras ver algo: la fila "Continuar viendo" se actualiza y el foco cae en ese título
    S.seen = false; var sp = spot(f); render(); if (!goSpot(sp)) { var c0 = $("#grid .rh.cont + .rr .card.f"); if (c0) foc(c0); else focFirst(); }
  } else if (f && document.body.contains(f)) foc(f); else focFirst();
  if (!S.layers.length) S.seen = false;
  if (id === "popts") ovShow();
  return true;
}
function openItem(x) {
  if (x.kind === "tv") return playChannel(x.ch);
  if (x.kind === "cont") return playCont(x);
  detail(x.rec);
}
function serieProg(r) { // último capítulo visto (o el siguiente) de esta serie, según el historial del perfil
  var k = r.kind + "|" + r.id, l = store.get();
  for (var i = 0; i < l.length; i++) if (l[i].k === k) return l[i];
  return null;
}
function detail(r) {
  nw.seen(r); var d = $("#detail"); d.querySelector(".bg").style.backgroundImage = r.back ? "url(" + r.back + ")" : "none"; d.classList.toggle("sr", r.kind === "series");
  d.querySelector(".in").innerHTML = (r.big ? '<img class="p" src="' + esc(r.big) + '">' : "") + '<div class="r"><h1>' + esc(r.title) + '</h1><div class="inf">' + esc([r.year, r.genre, rlabel(r)].filter(Boolean).join("  •  ")) + '</div><div class="plot">' + esc(r.plot) + "</div>" + (r.kind === "movie" ? '<div><button class="b f play" data-a="playm">▶ Reproducir</button></div>' : '<div id="seasons"></div><div id="eps"></div>') + "</div>"; S.cur = r;
  if (r.kind === "series") {
    var sn = [], cnt = {}; eplist(r).forEach(function (e) { if (sn.indexOf(e.sn) < 0) sn.push(e.sn); cnt[e.sn] = (cnt[e.sn] || 0) + 1; });
    $("#seasons").innerHTML = sn.map(function (n) { return '<button class="b f sn" data-a="season" data-v="' + n + '">Temporada ' + n + "<small>" + cnt[n] + (cnt[n] === 1 ? " cap." : " caps.") + "</small></button>"; }).join("");
    S.season = null; var sp = serieProg(r); // abre en la temporada donde te quedaste
    if (sn.length) showSeason(sp && sn.indexOf(sp.sn) > -1 ? sp.sn : sn[0]);
  }
  openLayer("detail");
  var first = r.kind === "movie" ? d.querySelector(".play") : ($("#eps .cur") || $("#eps .f")); if (first) foc(first);
}
function showSeason(n) {
  var r = S.cur, sp = serieProg(r), bk = r.back ? "url(" + r.back + ")" : "";
  S.season = n; [].forEach.call($("#seasons").children, function (b) { b.classList.toggle("on", +b.dataset.v === n); });
  $("#eps").innerHTML = eplist(r).map(function (e, i) {
    if (e.sn !== n) return "";
    var cur = sp && sp.sn === e.sn && sp.en === e.en, pct = cur && sp.dur > 0 && sp.at >= 60 ? Math.min(100, sp.at / sp.dur * 100) : 0, tg = cur ? (pct ? "Continuar" : "Siguiente") : "";
    return '<div class="ep f' + (cur ? " cur" : "") + '" tabindex="0" data-a="ep" data-i="' + i + '">' +
      '<div class="et" style="background-position:' + (e.en * 31 % 100) + "% " + (e.en * 53 % 100) + '%"><em class="n">' + e.en + '</em><span class="pl">▶</span>' + (pct ? '<div class="bar"><i style="width:' + pct.toFixed(1) + '%"></i></div>' : "") + "</div>" +
      '<div class="ex"><div class="eh"><b>' + esc(e.title || "Episodio " + e.en) + "</b>" + (tg ? '<i class="tg' + (pct ? "" : " nx") + '">' + tg + "</i>" : "") + (e.rt ? '<span class="rt">' + esc(e.rt) + "</span>" : "") + "</div>" + (e.desc ? '<div class="ed">' + esc(e.desc) + "</div>" : "") + "</div></div>";
  }).join("");
  if (bk) [].forEach.call($("#eps").querySelectorAll(".et"), function (t) { t.style.backgroundImage = bk; }); // cada capítulo muestra un recorte distinto del fondo de la serie
}

// ---------- Fuentes alternativas y subtítulos (campos OPCIONALES del panel) ----------
var LANGS = { es: "Español", en: "Inglés", pt: "Portugués", fr: "Francés", it: "Italiano", de: "Alemán", ja: "Japonés", ko: "Coreano", zh: "Chino", ru: "Ruso", la: "Español (Latino)", lat: "Español (Latino)", "es-419": "Español (Latino)", "es-mx": "Español (Latino)", "es-la": "Español (Latino)" };
function langName(c) { c = String(c || "").toLowerCase().trim(); return LANGS[c] || LANGS[c.split(/[-_]/)[0]] || ""; }
function urlOf(x) { if (typeof x === "string") return x; if (x && typeof x === "object") { x = lc(x); return x.url || x.src || x.file || x.link || x.href || ""; } return ""; }
function altList(e) { // fuentes de respaldo: urls / sources / alternates / backup / url2 / fallback / mirrors
  var out = [];
  ["urls", "sources", "alternates", "alternatives", "alts", "backup", "backups", "backupurl", "fallback", "fallbackurl", "mirror", "mirrors", "url2", "alternateurl"].forEach(function (k) {
    var v = e[k]; if (v == null || v === "") return;
    (Array.isArray(v) ? v : [v]).forEach(function (x) { var u = String(urlOf(x)).trim(); if (u && u !== e.url && out.indexOf(u) < 0) out.push(u); });
  });
  return out;
}
function subList(e) { // subtitles / subs / captions / subtitulos → [{url, lang, label}]
  var out = [];
  var add = function (u, lang, label) {
    u = String(u || "").trim(); if (!u || (!/^(https?:)?\/\//i.test(u) && !/\.(srt|vtt)(\?|#|$)/i.test(u))) return;
    lang = String(lang || "").trim(); if (!lang) { var m = /[._-]([a-z]{2,3}(?:-[a-z0-9]{2,3})?)\.(?:srt|vtt)(?:[?#]|$)/i.exec(u); if (m) lang = m[1]; }
    out.push({ url: u, lang: lang, label: String(label || "").trim() || langName(lang) || lang || "Subtítulos " + (out.length + 1) });
  };
  ["subtitles", "subtitle", "subs", "sub", "captions", "subtitulos", "subtítulos", "srt", "vtt"].forEach(function (k) {
    var v = e[k]; if (v == null || v === "") return;
    if (Array.isArray(v)) v.forEach(function (x) { if (typeof x === "string") add(x); else if (x && typeof x === "object") { var o = lc(x); add(o.url || o.src || o.file || o.link, o.lang || o.language || o.srclang || o.code, o.label || o.name || o.title); } });
    else if (typeof v === "object") Object.keys(v).forEach(function (l) { var y = v[l]; add(urlOf(y), l, y && typeof y === "object" ? lc(y).label : ""); });
    else add(v);
  });
  return out;
}
function tsec(x) { return x.replace(",", ".").split(":").reduce(function (a, p) { return a * 60 + parseFloat(p); }, 0); }
function parseSub(txt) { // acepta .srt y .vtt
  txt = String(txt || "").replace(/^﻿/, "").replace(/\r\n?/g, "\n");
  var cues = [], re = /((?:\d+:)?\d+:\d+[.,]\d+)\s*-->\s*((?:\d+:)?\d+:\d+[.,]\d+)/;
  txt.split(/\n{2,}/).forEach(function (blk) {
    var ls = blk.split("\n"), i = 0; while (i < ls.length && !re.test(ls[i])) i++; if (i >= ls.length) return;
    var m = re.exec(ls[i]), t = ls.slice(i + 1).join("\n").replace(/<[^>]*>/g, "").replace(/\{\\[^}]*\}/g, "").replace(/&nbsp;/g, " ").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&amp;/g, "&").trim();
    if (t) cues.push({ s: tsec(m[1]), e: tsec(m[2]), t: t });
  });
  cues.sort(function (a, b) { return a.s - b.s; }); return cues;
}
function decodeBuf(buf) { // UTF-8, y si no es válido (muchos .srt viejos) Windows-1252 para no romper acentos
  try { return new TextDecoder("utf-8", { fatal: true }).decode(buf); } catch (e) { }
  try { return new TextDecoder("windows-1252").decode(buf); } catch (e2) { }
  var u = new Uint8Array(buf), s = ""; for (var i = 0; i < u.length; i++) s += String.fromCharCode(u[i]); return s;
}
function cueAt(c, t) {
  var lo = 0, hi = c.length - 1, i = -1; while (lo <= hi) { var mid = (lo + hi) >> 1; if (c[mid].s <= t) { i = mid; lo = mid + 1; } else hi = mid - 1; }
  var out = []; for (var j = i; j >= 0 && j > i - 4; j--) if (c[j].e > t) out.unshift(c[j].t); return out.join("\n");
}

// ---------- Preferencias por perfil (idioma de subtítulos/audio, reproducción automática) ----------
function prefKey() { return "fenixpref_" + (S.me ? S.me.id : "x"); }
function getPref() { try { return JSON.parse(localStorage.getItem(prefKey()) || "{}") || {}; } catch (e) { return {}; } }
function setPref(o) { var p = getPref(); for (var k in o) p[k] = o[k]; try { localStorage.setItem(prefKey(), JSON.stringify(p)); } catch (e) { } }

// ---------- Reanudar / empezar de nuevo ----------
function progFor(r, sn, en) {
  var k = r.kind + "|" + r.id, l = store.get();
  for (var i = 0; i < l.length; i++) if (l[i].k === k) { var c = l[i]; if (r.kind === "series" && (c.sn !== sn || c.en !== en)) return null; return c.at >= 60 && c.dur > 0 ? c : null; }
  return null;
}
function askResume(r, sn, en, go) {
  var c = progFor(r, sn, en); if (!c) return go(0);
  S.rgo = go; S.rat = Math.max(0, c.at - 5);
  $("#rt").textContent = r.title;
  $("#rs").textContent = (r.kind === "series" ? "Temporada " + sn + "  •  Cap. " + en + "   —   " : "") + "Te quedaste en " + ft(c.at) + " de " + ft(c.dur) + "  (quedan " + mins(c.dur - c.at) + ")";
  $("#rsm").textContent = "▶  Reanudar desde " + ft(S.rat);
  openLayer("resume"); foc($("#rsm"));
}

// ---------- Reproductor ----------
var P = { busy: false, ctx: null, mk: null, t: null, srcs: [], si: 0, tries: 0, failed: false, subs: [], sub: -1, subOff: 0, userSub: false, cd: null, cdOff: false, rate: 1 };
var RATES = [0.75, 1, 1.25, 1.5, 2];
function pmsg(t, hint) { $("#pst").textContent = t; $("#phint").textContent = hint || ""; }
function play(o) {
  if (o.ctx && o.ctx.rec) nw.seen(o.ctx.rec);
  var v = $("#v"); stopCd(); clearTimeout(P.rt); clearTimeout(P.wd); clearInterval(P.subT); clearTimeout(P.skT); P.sk = null; P.ps = P.pds = null;
  if (S.layers[S.layers.length - 1] === "popts") closeLayer();
  P.ctx = o.ctx; P.mk = o.mk || { is: -1, ie: -1, nx: -1 }; P.at = o.at || 0; P.live = !!o.live;
  P.srcs = [o.url].concat(o.alts || []); P.si = 0; P.tries = 0; P.failed = false; P.cdOff = false; P.rate = 1;
  P.subs = (o.subs || []).map(function (s) { return { kind: "ext", url: s.url, lang: s.lang, label: s.label, cues: null }; }); P.sub = -1; P.subOff = 0; P.userSub = false; showCue("");
  $("#pti").textContent = o.title; $("#psu").textContent = o.sub || ""; pmsg("Cargando…");
  var sk = $("#skip"); sk.style.display = "none"; sk.dataset.m = ""; $("#skiph").style.display = "none"; $("#popt").style.display = P.live ? "none" : "block";
  $("#pb").style.visibility = $("#pt").style.visibility = P.live ? "hidden" : "visible";
  if (S.layers.indexOf("player") < 0) openLayer("player");
  document.body.classList.add("pl"); // lo de atrás deja de pintarse y animarse (ver CSS "body.pl")
  applyPrefSub(); startSrc(P.at); ovShow();
}
function startSrc(at) {
  var v = $("#v"); P.busy = true; P.at = at; v.src = P.srcs[P.si]; v.load(); var pr = v.play(); if (pr && pr.catch) pr.catch(function () { }); armWd();
}
function armWd() { clearTimeout(P.wd); P.wd = setTimeout(function () { if (P.ctx) onFail(); }, 25000); } // si se queda cargando 25 s, se trata como falla
function onFail() { // reintenta 2 veces la misma fuente, luego prueba las de respaldo; si todo falla, avisa y deja reintentar con OK
  var v = $("#v"); if (!P.ctx) return; clearTimeout(P.wd); clearTimeout(P.rt);
  var at = v.currentTime > 1 ? v.currentTime : P.at;
  if (P.live) { var np = nowPlaying(P.ctx.ch); at = np.i === P.ctx.pi ? np.off : 0; }
  if (P.tries < 2) { P.tries++; pmsg("Reintentando…  (" + P.tries + "/2)"); ovShow(true); P.rt = setTimeout(function () { if (P.ctx) startSrc(at); }, 1500 * P.tries); return; }
  if (P.si < P.srcs.length - 1) { P.si++; P.tries = 0; pmsg("Probando otra fuente…  (" + (P.si + 1) + "/" + P.srcs.length + ")"); ovShow(true); P.rt = setTimeout(function () { if (P.ctx) startSrc(at); }, 800); return; }
  P.failed = true; P.busy = true; P.at = at; pmsg("No se pudo reproducir este video", "OK: reintentar   •   Atrás: salir"); ovShow(true);
}
function retryNow() { clearTimeout(P.rt); P.si = 0; P.tries = 0; P.failed = false; pmsg("Cargando…"); startSrc(P.at); }
function stopPlayer() { var v = $("#v"); stopCd(); clearTimeout(P.t); clearTimeout(P.rt); clearTimeout(P.wd); clearTimeout(P.skT); P.sk = null; clearInterval(P.subT); if (P.st) { clearInterval(P.st); P.st = null; $("#stats").style.display = "none"; } P.ctx = null; showCue(""); pmsg(""); v.pause(); v.removeAttribute("src"); v.load(); }
function closePlayer() { while (S.layers.indexOf("player") > -1 && S.layers[S.layers.length - 1] !== "player") closeLayer(); closeLayer(); }
function ovShow(keep) { $("#ov").classList.add("on"); if (P.ctx && P.sk == null) { var v = $("#v"); paintTime(v.currentTime || 0, v.duration || 0); } clearTimeout(P.t); if (!keep && !$("#v").paused) P.t = setTimeout(function () { $("#ov").classList.remove("on"); }, 4000); }
// Barra de progreso y tiempos: solo se dibujan con los controles a la vista, la barra avanza con transform (sin recalcular el diseño) y el texto solo cambia cuando cambia
function paintTime(t, d) {
  var ok = d > 0 && isFinite(d), f = $("#pb").firstChild, w = ok ? Math.min(1, t / d) : 0, s = ft(t), ds = ok ? ft(d) : "", tf = "scaleX(" + w.toFixed(4) + ")";
  f.style.webkitTransform = tf; f.style.transform = tf;
  if (s !== P.ps) { P.ps = s; $("#pc").textContent = s; }
  if (ds !== P.pds) { P.pds = ds; $("#pd").textContent = ds; }
}
// Panel de diagnóstico (botón azul del control): sirve para saber si el problema es red (poco buffer), decodificación (cuadros perdidos) o el formato del archivo
function statsTick() {
  var v = $("#v"), t = v.currentTime || 0, b = 0, i, q = null, el = $("#stats");
  try { for (i = 0; i < v.buffered.length; i++) if (v.buffered.start(i) <= t + .5 && v.buffered.end(i) >= t) b = v.buffered.end(i) - t; } catch (e) { }
  try { q = v.getVideoPlaybackQuality ? v.getVideoPlaybackQuality() : null; } catch (e2) { }
  var drop = q ? q.droppedVideoFrames : v.webkitDroppedFrameCount, tot = q ? q.totalVideoFrames : v.webkitDecodedFrameCount, src = P.srcs[P.si] || "", fm = /\.(m3u8|mpd|mp4|m4v|mkv|webm|ts|mov|avi)(\?|#|$)/i.exec(src);
  el.textContent = "Resolución: " + (v.videoWidth ? v.videoWidth + "×" + v.videoHeight : "—") + "    Formato: " + (fm ? fm[1].toLowerCase() : "?") + "\nBuffer por delante: " + b.toFixed(1) + " s\nCuadros perdidos: " + (drop == null ? "n/d" : drop + " de " + tot) + "\nFuente " + (P.si + 1) + " de " + P.srcs.length + "    Velocidad " + P.rate + "×";
}
function toggleStats() {
  var el = $("#stats"); if (P.st) { clearInterval(P.st); P.st = null; el.style.display = "none"; return; }
  el.style.display = "block"; statsTick(); P.st = setInterval(statsTick, 1000);
}
function toast(t) { var e = $("#toast"); e.textContent = t; e.style.display = "block"; clearTimeout(toast.t); toast.t = setTimeout(function () { e.style.display = "none"; }, 3000); }
function playEp(r, i, at) {
  var e = eplist(r)[i];
  play({ url: e.url, alts: e.alts, subs: e.subs, title: r.title, sub: "Temporada " + e.sn + "  •  Cap. " + e.en + (e.title ? "  •  " + e.title : ""), mk: e.mk, at: at, ctx: { rec: r, qi: i, sn: e.sn, en: e.en } });
}
function playMovie(r, at) { play({ url: r.e.url, alts: altList(r.e), subs: subList(r.e), title: r.title, sub: [r.year, r.genre].filter(Boolean).join("  •  "), mk: markers(r.e), at: at, ctx: { rec: r } }); }
function playCont(x) {
  var r = x.rec, c = x.c, at = Math.max(0, c.at - 5);
  if (r.kind === "movie") return playMovie(r, at);
  var l = eplist(r), i = -1; l.forEach(function (e, j) { if (e.sn === c.sn && e.en === c.en) i = j; });
  playEp(r, i < 0 ? 0 : i, i < 0 ? 0 : at);
}
function playChannel(ch, pi, off) {
  var np = nowPlaying(ch); if (pi == null) { pi = np.i; off = np.off; } var p = ch.progs[pi];
  play({ url: p.url, alts: p.alts, title: ch.name, sub: "EN VIVO  •  " + p.title, live: true, at: off, ctx: { live: true, ch: ch, pi: pi } });
}
function zap(d) { var c = P.ctx.ch, i = (S.tv.indexOf(c) + d + S.tv.length) % S.tv.length; playChannel(S.tv[i]); }
function nextEp() { var x = P.ctx; if (x && x.rec && x.rec.kind === "series" && eplist(x.rec)[x.qi + 1]) { saveProg(); playEp(x.rec, x.qi + 1, 0); return true; } return false; }
function seek(d) { // varios saltos seguidos (mantener la flecha) se juntan en UNO solo: cada salto real obliga al TV a pedir y re-decodificar desde otro punto
  if (P.live) return; var v = $("#v"), du = v.duration, mx = du > 0 && isFinite(du) ? du : 1e9;
  P.sk = Math.max(0, Math.min(mx, (P.sk != null ? P.sk : v.currentTime) + d));
  paintTime(P.sk, du); ovShow(); clearTimeout(P.skT);
  P.skT = setTimeout(function () { var t = P.sk; P.sk = null; if (P.ctx && t != null) v.currentTime = t; }, 380);
}
function pause() { var v = $("#v"); if (P.live) return; if (v.paused) v.play(); else v.pause(); }

// ---- Siguiente capítulo con cuenta regresiva ----
function skipText() {
  var sk = $("#skip"), m = sk.dataset.m;
  if (m === "intro") sk.textContent = "Saltar intro ⏭"; else if (m === "next") sk.textContent = P.cd ? "Siguiente capítulo en " + P.cd.n + " s ⏭" : "Siguiente capítulo ⏭";
  $("#skiph").style.display = m === "next" && P.cd ? "block" : "none";
}
function startCd() {
  stopCd(); P.cd = { n: 10 };
  P.cd.t = setInterval(function () { if (!P.ctx) return stopCd(); if ($("#v").paused) return; P.cd.n--; if (P.cd.n <= 0) { stopCd(); nextEp(); } else skipText(); }, 1000);
  skipText();
}
function stopCd() { if (P.cd) clearInterval(P.cd.t); P.cd = null; }
function cancelCd() { stopCd(); P.cdOff = true; skipText(); }

// ---- Subtítulos ----
function showCue(t) {
  var el = $("#sub"); if (el.dataset.t === t) return; el.dataset.t = t;
  el.innerHTML = t ? "<span>" + esc(t).replace(/\n/g, "</span><br><span>") + "</span>" : ""; el.style.display = t ? "block" : "none";
}
function subTick() {
  var v = $("#v"), s = P.subs[P.sub], txt = ""; if (!s) return showCue("");
  if (s.kind === "emb") { var ac = s.tr.activeCues; if (ac) for (var i = 0; i < ac.length; i++) txt += (txt ? "\n" : "") + String(ac[i].text || "").replace(/<[^>]*>/g, ""); }
  else if (s.cues) txt = cueAt(s.cues, v.currentTime - P.subOff);
  showCue(txt);
}
function loadSub(s) {
  if (s.loading) return; s.loading = true;
  fetch(s.url).then(function (r) { if (!r.ok) throw new Error("HTTP " + r.status); return r.arrayBuffer(); }).then(function (b) {
    s.loading = false; var c = parseSub(decodeBuf(b));
    if (!c.length) { if (P.subs[P.sub] === s) toast("El archivo de subtítulos está vacío o no es válido"); return; }
    s.cues = c; subTick();
  }).catch(function () { s.loading = false; if (P.subs[P.sub] === s) toast("No se pudieron cargar los subtítulos"); });
}
function selectSub(i, user) {
  var old = P.subs[P.sub]; if (old && old.tr) old.tr.mode = "disabled";
  clearInterval(P.subT); P.sub = i; showCue(""); if (user) P.userSub = true;
  var s = P.subs[i];
  if (s) { if (s.kind === "emb") s.tr.mode = "hidden"; else if (!s.cues) loadSub(s); P.subT = setInterval(subTick, 200); subTick(); }
  if (user) setPref({ sl: s ? subKey(s) : "off" });
}
function subKey(s) { return String(s.lang || s.label || "").toLowerCase(); }
function refreshEmb() {
  var tl = $("#v").textTracks; if (!tl) return;
  for (var i = 0; i < tl.length; i++) { var tt = tl[i]; if ((tt.kind === "subtitles" || tt.kind === "captions") && !tt.fx) { tt.fx = 1; tt.mode = "disabled"; P.subs.push({ kind: "emb", tr: tt, lang: tt.language || "", label: tt.label || langName(tt.language) || "Incluido " + (P.subs.length + 1) }); } }
}
function applyPrefSub() {
  if (P.live || P.sub >= 0 || P.userSub) return; var sl = getPref().sl; if (!sl || sl === "off") return;
  for (var i = 0; i < P.subs.length; i++) if (subKey(P.subs[i]) === sl) { selectSub(i, false); return; }
}
// ---- Audio ----
function audioList() {
  var l = []; try { var at = $("#v").audioTracks; if (at && at.length > 1) for (var i = 0; i < at.length; i++) l.push({ i: i, label: at[i].label || langName(at[i].language) || "Pista " + (i + 1), on: !!at[i].enabled }); } catch (e) { } return l;
}
function selectAudio(i, user) {
  try { var at = $("#v").audioTracks; for (var j = 0; j < at.length; j++) at[j].enabled = j === i; if (user) setPref({ al: String(at[i].language || at[i].label || "").toLowerCase() }); } catch (e) { }
}
function applyPrefAudio() {
  if (P.live) return; var al = getPref().al; if (!al) return;
  try { var at = $("#v").audioTracks; if (!at || at.length < 2) return; for (var i = 0; i < at.length; i++) if (String(at[i].language || at[i].label || "").toLowerCase() === al) { if (!at[i].enabled) selectAudio(i, false); return; } } catch (e) { }
}
// ---- Panel de opciones (▲ o botón amarillo) ----
function orow(a, v, label, on) { return '<button class="b f row' + (on ? " on" : "") + '" data-a="' + a + '" data-v="' + v + '">' + esc(label) + "</button>"; }
function renderOpts() {
  var h = "<h3>Subtítulos</h3>" + orow("psub", -1, "Desactivados", P.sub < 0);
  P.subs.forEach(function (s, i) { h += orow("psub", i, s.label + (s.kind === "emb" ? "  (incluido)" : ""), P.sub === i); });
  if (!P.subs.length) h += '<div class="pnote">Este video no trae subtítulos.</div>';
  var cs = P.subs[P.sub];
  if (cs && cs.kind === "ext") h += '<div class="prow"><span>Sincronía</span><button class="b f" data-a="psync" data-v="-0.5">−0.5 s</button><em>' + (P.subOff > 0 ? "+" : "") + P.subOff.toFixed(1) + ' s</em><button class="b f" data-a="psync" data-v="0.5">+0.5 s</button></div>';
  h += "<h3>Audio</h3>"; var au = audioList();
  if (au.length) au.forEach(function (a) { h += orow("paud", a.i, a.label, a.on); }); else h += '<div class="pnote">Este video tiene una sola pista de audio.</div>';
  h += '<h3>Velocidad</h3><div class="prow">' + RATES.map(function (r) { return '<button class="b f' + (P.rate === r ? " on" : "") + '" data-a="prate" data-v="' + r + '">' + r + "×</button>"; }).join("") + "</div>";
  if (P.ctx && P.ctx.rec && P.ctx.rec.kind === "series") h += "<h3>Siguiente capítulo</h3>" + orow("pauto", 0, "Reproducir automáticamente", getPref().auto !== false);
  $("#pcol").innerHTML = h;
}
function openOpts() {
  if (!P.ctx || P.live || S.layers[S.layers.length - 1] !== "player") return;
  refreshEmb(); renderOpts(); openLayer("popts"); foc($("#pcol .row.on") || $("#pcol .f"));
}
function optsDo(a, v) {
  if (a === "psub") selectSub(+v, true);
  else if (a === "paud") selectAudio(+v, true);
  else if (a === "prate") { P.rate = +v; $("#v").playbackRate = P.rate; }
  else if (a === "psync") { P.subOff = Math.round((P.subOff + parseFloat(v)) * 10) / 10; subTick(); }
  else if (a === "pauto") setPref({ auto: getPref().auto === false });
  renderOpts(); var f = $('#pcol [data-a="' + a + '"][data-v="' + v + '"]'); if (f) foc(f);
}

(function () {
  var v = $("#v"), last = 0;
  v.addEventListener("loadedmetadata", function () {
    if (P.at > 0 && isFinite(v.duration) && !P.live) v.currentTime = P.at; else if (P.live && P.at > 0) try { v.currentTime = P.at; } catch (e) { }
    P.subs = P.subs.filter(function (s) { return s.kind === "ext"; }); if (P.sub >= P.subs.length) { clearInterval(P.subT); P.sub = -1; showCue(""); }
    refreshEmb(); applyPrefSub(); applyPrefAudio();
  });
  v.addEventListener("playing", function () { P.busy = false; pmsg(""); P.tries = 0; clearTimeout(P.wd); ovShow(); });
  v.addEventListener("waiting", function () { if (!P.failed && !/^(Reintentando|Probando)/.test($("#pst").textContent)) pmsg("Cargando…"); armWd(); });
  v.addEventListener("pause", function () { clearTimeout(P.wd); if (P.busy) return; if (S.layers.indexOf("player") > -1) { $("#pst").textContent = "⏸"; ovShow(true); } });
  v.addEventListener("play", function () { if ($("#pst").textContent === "⏸") { pmsg(""); ovShow(); } });
  v.addEventListener("error", function () { if (P.ctx) onFail(); });
  v.addEventListener("ended", function () {
    var x = P.ctx; if (!x) return; clearTimeout(P.wd);
    if (x.live) { var n = (x.pi + 1) % x.ch.progs.length; return playChannel(x.ch, n, 0); }
    if (getPref().auto !== false && !P.cdOff && nextEp()) return;
    saveProg(); closePlayer();
  });
  v.addEventListener("timeupdate", function () {
    var t = v.currentTime, d = v.duration || 0; if (!P.ctx) return;
    if (P.sk == null && $("#ov").classList.contains("on")) paintTime(t, d); // controles ocultos = nada que dibujar
    var m = P.mk, sk = $("#skip"), mode = "";
    var hasNext = P.ctx.rec && P.ctx.rec.kind === "series" && eplist(P.ctx.rec)[P.ctx.qi + 1], nxAt = m.nx >= 0 ? m.nx : (d > 180 ? d - 25 : -1);
    if (m.ie > 0 && t >= m.is && t < m.ie - 1) mode = "intro"; else if (hasNext && nxAt >= 0 && t >= nxAt) mode = "next";
    if (mode !== sk.dataset.m) {
      sk.dataset.m = mode; sk.style.display = mode ? "block" : "none";
      if (mode === "next" && getPref().auto !== false && !P.cdOff) startCd(); else { stopCd(); skipText(); }
    }
    if (Date.now() - last > 15000) { last = Date.now(); saveProg(); }
  });
})();

// ---------- Buscador ----------
function openSearch() { S.sq = $("#q").value = ""; S.ss = "all"; openLayer("search"); doSearch(); foc($("#q")); }
function doSearch() {
  var q = norm($("#q").value).trim(), toks = q.split(/\s+/).filter(Boolean), all = [];
  recs("movie").forEach(function (r) { all.push({ kind: "movie", rec: r, title: r.title, poster: r.poster, h: norm(r.title + " " + r.genre + " " + r.year), tl: "PELÍCULA" }); });
  recs("series").forEach(function (r) { all.push({ kind: "series", rec: r, title: r.title, poster: r.poster, h: norm(r.title + " " + r.genre + " " + r.year), tl: "SERIE" }); });
  S.tv.forEach(function (c) { all.push({ kind: "tv", ch: c, title: c.name, poster: c.logo, h: norm(c.name), tl: "EN VIVO" }); });
  var res = [], cnt = { movie: 0, series: 0, tv: 0 };
  if (toks.length) all.forEach(function (x) {
    if (!toks.every(function (t) { return x.h.indexOf(t) > -1; })) return;
    var tn = norm(x.title); x.sc = tn.indexOf(q) === 0 ? 0 : (" " + tn).indexOf(" " + toks[0]) > -1 ? 1 : 2; res.push(x); cnt[x.kind]++;
  });
  res.sort(function (a, b) { return a.sc - b.sc || (a.title < b.title ? -1 : 1); });
  var shown = res.filter(function (x) { return S.ss === "all" || x.kind === S.ss; }).slice(0, 80); S.items = shown;
  $("#sc").innerHTML = [["all", "Todo"], ["movie", "Películas"], ["series", "Series"], ["tv", "TV"]].map(function (s) { return '<span class="b f' + (S.ss === s[0] ? " on" : "") + '" tabindex="0" data-a="scope" data-v="' + s[0] + '">' + s[1] + "</span>"; }).join("");
  $("#sinfo").textContent = toks.length ? res.length + " resultados • Películas " + cnt.movie + " • Series " + cnt.series + " • TV " + cnt.tv : "Escribe para buscar";
  $("#sg").innerHTML = cards(shown, false, function (x) { return '<i class="tag r">' + x.tl + "</i>"; }); observe("#sg");
}

// ---------- Bienvenida / perfiles ----------
function renderProfile() {
  var b = $("#me"); if (!S.me) { b.style.display = "none"; return; }
  b.innerHTML = avHtml(avOf(S.me.a), "pav") + '<span class="pn">' + esc(S.me.n) + "</span>"; b.style.display = "";
}
function findP(id) { for (var i = 0; i < S.ps.length; i++) if (S.ps[i].id === id) return S.ps[i]; return null; }
function pickAvatar(id) {
  S.pick = id;
  [].forEach.call(document.querySelectorAll("#wav .av"), function (e) { e.classList.toggle("sel", e.dataset.v === id); });
}
function disarm() { clearTimeout(S.delT); S.delArm = false; $("#wdel").textContent = "Eliminar perfil"; }
// mode: "first" (primer perfil), "new" (agregar otro) o "edit" (editar el perfil con ese id)
function openWelcome(mode, id) {
  S.wm = mode; S.first = mode === "first"; S.editId = id || null; disarm();
  var w = $("#welcome"), p = mode === "edit" ? findP(id) : null;
  w.classList.toggle("edit", mode !== "first"); w.classList.toggle("del", mode === "edit" && S.ps.length > 1);
  $("#wt").textContent = mode === "first" ? "Bienvenido a FÉNIX TV" : mode === "new" ? "Nuevo perfil" : "Editar perfil";
  $("#ws").textContent = mode === "first" ? "Antes de empezar, dinos cómo te llamas y elige tu avatar." : mode === "new" ? "Cada perfil tiene su propio historial de «Continuar viendo»." : "Cambia el nombre o el avatar.";
  $("#wgo").textContent = mode === "first" ? "Comenzar  ▶" : mode === "new" ? "Crear perfil" : "Guardar cambios";
  $("#nm").value = p ? p.n : "";
  $("#wav").innerHTML = AV.map(function (a) { return '<div class="av f" tabindex="0" data-a="avatar" data-v="' + a.id + '"><i class="ck">' + CHECK + "</i>" + avHtml(a, "ac") + "<b>" + esc(a.n) + "</b></div>"; }).join("");
  openLayer("welcome");
  pickAvatar(p ? avOf(p.a).id : null);
  foc($("#nm"));
}
function enterProfile(p, first) {
  S.me = p; prof.setLast(p.id); renderProfile();
  var t; while ((t = S.layers[S.layers.length - 1]) === "welcome" || t === "who") closeLayer();
  if (S.vod) render();
  focSide(); // al entrar a un perfil, el foco empieza en el menú lateral (Películas)
  toast((first ? "¡Bienvenido, " : "¡Hola, ") + p.n + "!");
}
function saveProfile() {
  var n = $("#nm").value.replace(/\s+/g, " ").trim().slice(0, 16);
  if (!n) { toast("Escribe tu nombre para continuar"); foc($("#nm")); return; }
  if (!S.pick) { toast("Elige uno de los avatares para continuar"); foc($("#wav .av")); return; }
  if (S.wm === "edit") {
    var p = findP(S.editId); if (!p) { closeLayer(); return; }
    p.n = n; p.a = S.pick; prof.save(S.ps);
    if (S.me && S.me.id === p.id) { S.me = p; renderProfile(); }
    closeLayer(); renderWho(); var c = $('#wlist [data-v="' + p.id + '"]'); if (c) foc(c);
    toast("Perfil actualizado"); return;
  }
  var q = { id: prof.newId(), n: n, a: S.pick }; S.ps.push(q); prof.save(S.ps);
  enterProfile(q, S.wm === "first");
}
function deleteProfile() {
  if (S.wm !== "edit" || S.ps.length < 2) return;
  if (!S.delArm) { S.delArm = true; $("#wdel").textContent = "Presiona OK otra vez para confirmar"; clearTimeout(S.delT); S.delT = setTimeout(disarm, 4000); return; }
  disarm();
  var id = S.editId; S.ps = S.ps.filter(function (p) { return p.id !== id; }); prof.save(S.ps);
  try { localStorage.removeItem("fenixcont_" + id); localStorage.removeItem("fenixseen_" + id); localStorage.removeItem("fenixpref_" + id); if (prof.last() === id) localStorage.removeItem("fenixactive"); } catch (e) { }
  if (S.me && S.me.id === id) { S.me = null; renderProfile(); }
  closeLayer();
  if (!S.me && S.ps.length === 1) { enterProfile(S.ps[0], false); return; }
  renderWho(); foc($("#wlist .av")); toast("Perfil eliminado");
}
// ---- Selector "¿Quién está viendo?" ----
function renderWho() {
  var h = S.ps.map(function (p) { return '<div class="av f" tabindex="0" data-a="who" data-v="' + p.id + '"><i class="pen">' + PEN + "</i>" + avHtml(avOf(p.a), "ac") + "<b>" + esc(p.n) + "</b></div>"; }).join("");
  if (S.ps.length < PMAX) h += '<div class="av f add" tabindex="0" data-a="newp"><span class="ac plus">' + PLUS + "</span><b>Agregar</b></div>";
  $("#wlist").innerHTML = h;
}
function setManage(on) {
  S.manage = on; $("#who").classList.toggle("mg", on);
  $("#wwt").textContent = on ? "Administrar perfiles" : "¿Quién está viendo?"; $("#wmg").textContent = on ? "Listo" : "Administrar perfiles";
}
function openWho() {
  setManage(false); renderWho(); openLayer("who");
  var cur = S.me ? S.me.id : prof.last(), t = cur && $('#wlist [data-v="' + cur + '"]');
  foc(t || $("#wlist .av"));
}

// ---------- Menú lateral: visible al iniciar (foco en Películas); al pasar al contenido se oculta y solo vuelve con ◀ (1.0.29) ----------
// Reglas (solo cuando no hay otra pantalla encima):
//  • Se OCULTA al bajar por la lista (más de ~14 rem de scroll) o si el elemento enfocado quedaría cortado por el borde derecho.
//  • Se MUESTRA al volver arriba, al pulsar ◀ en el primer póster de una fila, al enfocar una de sus opciones o al llevar el puntero al borde izquierdo.
// El contenido (#main) nunca cambia de tamaño: solo se desplaza con transform, así que los pósters y el scroll no se recalculan.
var SW = 31; // ancho del menú en rem (igual que #side en index.html)
var SIDE = { on: true, ptr: false }; // 1.0.29: al iniciar el menú se ve y el foco está en "Películas"; al pasar al contenido se oculta
function fsz() { return parseFloat(document.documentElement.style.fontSize) || 10; }
function side(on) {
  if (SIDE.on === on) return; SIDE.on = on;
  E_APP.classList.toggle("sd", on); E_SIDE.classList.toggle("hid", !on);
}
function sideAuto(fe) { // fe === true: acaba de enfocarse algo del contenido. Decide con lo ya medido (S.fl / S.fr los pone sideNote): no lee el diseño durante el scroll
  if (S.layers.length) return;
  var fs = fsz(), st = E_GRID.scrollTop, a = document.activeElement;
  if (SIDE.ptr || (a && E_SIDE.contains(a))) return side(true); // foco en el menú = menú visible
  if (SIDE.on) { if (a && E_MAIN.contains(a) && (fe === true || st > 14 * fs)) side(false); return; } // el foco pasó al contenido (o bajaste) = el menú se oculta
  // 1.0.28: ya NO reaparece solo al volver arriba (ni en el banner): solo con ◀ en el primer elemento de la fila, al enfocar el menú o con el puntero en el borde izquierdo
}
function sideNote(e) { // se llama al enfocar algo: guarda dónde quedó y revisa el menú
  if (S.layers.length) return;
  if (E_SIDE.contains(e)) { side(true); return; }
  if (!E_MAIN.contains(e)) return;
  var mr = E_MAIN.getBoundingClientRect(), er = e.getBoundingClientRect();
  S.lastC = e; S.fl = er.left - mr.left; S.fr = er.right - mr.left; sideAuto(true);
  clearTimeout(sideNote.t); sideNote.t = setTimeout(function () { if (document.activeElement === e) { mr = E_MAIN.getBoundingClientRect(); er = e.getBoundingClientRect(); S.fl = er.left - mr.left; S.fr = er.right - mr.left; sideAuto(); } }, 340); // otra vez con la posición final, ya terminado el desplazamiento
}
function focSide() { var t = $("#nav .on") || $("#nav .f"); if (t) foc(t); }
E_GRID.addEventListener("scroll", sideAuto, { passive: true });

// ---------- Navegación ----------
// ---------- 1.0.31: volver al mismo sitio ----------
function cardKey(c) { // "tipo|id" del título de una tarjeta (las de "Continuar viendo" no llevan data-rk: se saca de la lista)
  var k = c.getAttribute("data-rk"), x;
  if (k) return k;
  x = S.items && S.items[+c.getAttribute("data-i")];
  return x && x.rec && x.rec.id != null ? x.rec.kind + "|" + x.rec.id : "";
}
function rowName(rr) { var h = rr && rr.previousElementSibling; return h && h.classList.contains("rh") && h.firstChild ? String(h.firstChild.nodeValue).replace(/^★ /, "") : ""; }
function spot(f) { // dónde estabas antes de abrir un título: la tarjeta (con su fila y su desplazamiento) o un botón del banner
  var g = $("#grid"), s, rw;
  if (!f || !g.contains(f)) return null;
  s = { gt: g.scrollTop, id: f.id || "", key: "", row: "", rl: 0 }; rw = f.parentNode;
  if (rw && rw.classList && rw.classList.contains("rw")) { s.key = cardKey(f); s.row = rowName(rw.parentNode); s.rl = rw.scrollLeft; }
  return s.key || s.id ? s : null;
}
function cardIn(rr, key) { var c = rr.firstElementChild && rr.firstElementChild.firstElementChild; while (c) { if (c.classList.contains("f") && cardKey(c) === key) return c; c = c.nextElementSibling; } return null; }
function goSpot(s) { // tras redibujar el inicio: vuelve a ese mismo título en esa misma fila, ya colocado (sin animar desde arriba)
  if (!s) return false;
  var g = $("#grid"), t = null, rows, i, rw;
  if (s.key) {
    rows = g.querySelectorAll(".rr");
    for (i = 0; i < rows.length && !t; i++) if (rowName(rows[i]) === s.row) t = cardIn(rows[i], s.key);
    for (i = 0; i < rows.length && !t; i++) t = cardIn(rows[i], s.key); // si ya no está en esa fila (p. ej. "Continuar viendo"), donde esté
  } else if (s.id) t = $("#" + s.id);
  if (!t) return false;
  g.scrollTop = Math.max(0, Math.min(s.gt, g.scrollHeight - g.clientHeight)); rw = t.parentNode;
  if (rw && rw.classList && rw.classList.contains("rw") && s.key && rowName(rw.parentNode) === s.row) rw.scrollLeft = Math.min(s.rl, Math.max(0, rw.scrollWidth - rw.clientWidth));
  S.inst = true; try { foc(t); } finally { S.inst = false; }
  return true;
}
// ---------- 1.0.30: navegación fluida ----------
var GCH0 = 42, GCH = 28, GAHEAD = 16; // lista plana: tarjetas del primer dibujo, tamaño de cada tanda y cuántas deben quedar por delante antes de dibujar la siguiente
var PS = false; try { var pso = { get preventScroll() { PS = true; return false; } }; document.createElement("div").focus(pso); } catch (x) { }
function kf(e) { // enfoca sin desplazar: el desplazamiento lo hace la app con su animación. Si el navegador es viejo y ignora preventScroll, se devuelve cada contenedor a su sitio
  if (PS) { e.focus({ preventScroll: true }); return; }
  var s = [], p = e.parentNode, i;
  while (p && p.nodeType === 1) { s.push(p, p.scrollTop, p.scrollLeft); p = p.parentNode; }
  e.focus();
  for (i = 0; i < s.length; i += 3) { if (s[i].scrollTop !== s[i + 1]) s[i].scrollTop = s[i + 1]; if (s[i].scrollLeft !== s[i + 2]) s[i].scrollLeft = s[i + 2]; }
}
function growGrid(e) { // lista plana grande: se dibuja por tandas; al acercarte al final de lo dibujado se agrega la siguiente
  var all = S.gall, n = S.gn, nx = e, i, part;
  if (!all || n >= all.length) return;
  for (i = 0; i < GAHEAD && nx; i++) nx = nx.nextElementSibling;
  if (nx) return;
  part = all.slice(n, n + GCH); S.gn = n + part.length;
  $("#grid").insertAdjacentHTML("beforeend", cards(part, S.tab === "tv", null, n, null)); observe("#grid");
}
function gridScroll(p, e, m) { // lista plana (categorías, TV): lleva la fila del foco a la vista con el mismo desplazamiento suave del inicio
  growGrid(e);
  var cur = p.scrollTop, base = p._ty != null ? p._ty : cur, vh = p.clientHeight, top = e.offsetTop, bot = top + e.offsetHeight, t = base;
  if (bot > base + vh - m) t = bot - vh + m; else if (top < base + m) t = top - m;
  t = Math.max(0, Math.min(t, p.scrollHeight - vh)); if (Math.abs(t - base) < 1) return;
  p._ty = t; tween(p, "scrollTop", cur, t);
}
function gridVert(a, dir) { // tarjeta de la fila de arriba/abajo más alineada con la actual; solo recorre unas pocas vecinas (offsetTop/Left: no fuerzan diseño ni cambian al hacer zoom o desplazar)
  var x = a.offsetLeft, y = a.offsetTop, n = a, best = null, bd = 1e9, ty = null, ny, dx, st = dir === "d" ? "nextElementSibling" : "previousElementSibling";
  while ((n = n[st])) {
    if (!n.classList.contains("f")) continue;
    ny = n.offsetTop; if (ny === y) continue;
    if (ty === null) ty = ny; else if (ny !== ty) break;
    dx = Math.abs(n.offsetLeft - x); if (dx < bd) { bd = dx; best = n; }
  }
  return best;
}
function rowVert(a, dir) { // inicio: tarjeta de la fila de abajo/arriba más cerca (en horizontal) de la actual; undefined = hay banner arriba, lo resuelve la búsqueda general
  var rr = a.parentNode.parentNode, n = dir === "d" ? rr.nextElementSibling : rr.previousElementSibling, w, c, r, d, cx, best = null, bd = 1e9;
  if (n) n = dir === "d" ? n.nextElementSibling : n.previousElementSibling; // se salta el título de la fila
  if (!n) return dir === "d" ? false : undefined;
  if (!n.classList.contains("rr")) return undefined;
  r = a.getBoundingClientRect(); cx = r.left + r.width / 2;
  for (c = n.firstElementChild.firstElementChild; c; c = c.nextElementSibling) { r = c.getBoundingClientRect(); d = Math.abs(r.left + r.width / 2 - cx); if (d < bd) { bd = d; best = c; } }
  return best || undefined;
}
function fastMove(a, dir, top) { // elemento = enfocar ese; false = resuelto (no hay a dónde ir); undefined = que lo resuelva la búsqueda general
  var par = a.parentNode, n;
  if (!par) return;
  if (par.id === "grid" || par.id === "sg") {
    if (dir === "l" || dir === "r") {
      n = dir === "l" ? a.previousElementSibling : a.nextElementSibling;
      if (n && n.classList.contains("f") && Math.abs(n.offsetTop - a.offsetTop) < 4) return n;
      if (dir === "l" && !top) focSide(); // ◀ en el primer póster de la fila: abre el menú lateral
      return false;
    }
    return gridVert(a, dir) || (dir === "d" ? false : undefined);
  }
  if (par.classList.contains("rw")) {
    if (dir === "l" || dir === "r") {
      n = dir === "l" ? a.previousElementSibling : a.nextElementSibling;
      if (n && n.classList.contains("f")) return n;
      if (dir === "l" && !top) focSide();
      return false;
    }
    return rowVert(a, dir);
  }
}
function foc(e) {
  if (!S.layers.length && E_SIDE.contains(e)) { side(true); void E_SIDE.offsetWidth; } // un elemento del menú oculto no se puede enfocar: primero se muestra
  kf(e); sideNote(e);
  var fs = parseFloat(document.documentElement.style.fontSize) || 10, m = fs * 4, er = e.getBoundingClientRect(), p = e.parentNode;
  while (p && p !== document.body) {
    if (p.nodeType === 1 && p.classList.contains("rw")) { rowScroll(p, e, m); p = p.parentNode; continue; }
    if (p.nodeType === 1 && p.id === "grid") { if (S.home) colScroll(p, e, m); else gridScroll(p, e, m); break; } // 1.0.30: sin querySelector sobre todo el catálogo; la lista plana también se desplaza con animación
    if (p.nodeType === 1 && (p.scrollHeight > p.clientHeight + 2 || p.scrollWidth > p.clientWidth + 2) && /auto|hidden/.test(getComputedStyle(p).overflowY + getComputedStyle(p).overflowX) && p.id !== "stage") {
      var pr = p.getBoundingClientRect();
      if (er.bottom > pr.bottom - m) p.scrollTop += er.bottom - pr.bottom + m; else if (er.top < pr.top + m) p.scrollTop -= pr.top + m - er.top;
      if (er.right > pr.right - m) p.scrollLeft += er.right - pr.right + m; else if (er.left < pr.left + m) p.scrollLeft -= pr.left + m - er.left;
      er = e.getBoundingClientRect();
    }
    p = p.parentNode;
  }
}
function focFirst() { // en la pantalla principal: lo primero del contenido (banner o primer póster); si no hay nada, la opción activa del menú
  var r = S.layers.length ? $("#" + S.layers[S.layers.length - 1]) : E_MAIN, e = [].filter.call(r.querySelectorAll("#hero .f"), function (x) { return x.offsetParent !== null; })[0] || r.querySelector(".card.f") || r.querySelector(".f");
  if (!e && !S.layers.length) e = $("#nav .on") || $("#nav .f"); if (e) foc(e);
}
// Orden vertical fijo en la bienvenida: nombre → avatares → Comenzar (la navegación espacial se saltaría los avatares)
function wnav(dir, a) {
  var av = $("#wav .av.sel") || $("#wav .av"), id = a && a.id;
  if (id === "nm") return dir === "d" ? av : $("#welcome.edit .wx");
  if (a && a.classList.contains("av")) return dir === "d" ? $("#wgo") : $("#nm");
  if (id === "wgo") return dir === "u" ? av : $("#welcome.del .wdel");
  if (a && a.classList.contains("wdel")) return dir === "u" ? $("#wgo") : null;
  if (a && a.classList.contains("wx")) return dir === "d" ? $("#nm") : null;
}
function move(dir) {
  var top = S.layers.length, root = top ? $("#" + S.layers[S.layers.length - 1]) : E_APP, a = document.activeElement;
  if (root.id === "welcome" && (dir === "u" || dir === "d") && a && root.contains(a)) { var wt = wnav(dir, a); if (wt !== undefined) { if (wt) foc(wt); return; } }
  var inSide = !top && !!a && E_SIDE.contains(a);
  if (inSide) { // menú lateral: ▲▼ entre sus opciones, ▶ vuelve al contenido (donde ibas), ◀ no hace nada
    if (dir === "r") { S.down = false; var lc = S.lastC; if (lc && document.body.contains(lc) && lc.offsetParent !== null) foc(lc); else focFirst(); return; }
    if (dir === "l") return;
  }
  if (!inSide && a && a.classList.contains("card") && a.classList.contains("f") && root.contains(a)) { var fm = fastMove(a, dir, !!top); if (fm) { foc(fm); return; } if (fm === false) return; } // 1.0.30: vecina directa, sin medir cada tarjeta del catálogo
  // en la pantalla principal el menú y el contenido son zonas separadas: las flechas no saltan de una a otra por sí solas
  var els = [].filter.call(root.querySelectorAll(".f"), function (e) { return e.offsetParent !== null && (top || E_SIDE.contains(e) === inSide); });
  if (!a || !root.contains(a) || !a.classList.contains("f")) { if (!top) return focFirst(); return els[0] && foc(els[0]); }
  var r = a.getBoundingClientRect(), cx = r.left + r.width / 2, cy = r.top + r.height / 2, best = null, bs = 1e9, band = !top && (dir === "l" || dir === "r") ? r.height * .45 + fsz() : 1e9;
  els.forEach(function (e) {
    if (e === a) return; var q = e.getBoundingClientRect(), x = q.left + q.width / 2 - cx, y = q.top + q.height / 2 - cy;
    var d = dir === "l" ? -x : dir === "r" ? x : dir === "u" ? -y : y; if (d <= 4) return;
    if (Math.abs(y) > band && (dir === "l" || dir === "r")) return; // ◀▶ en la pantalla principal solo dentro de la misma fila
    var s = d + (dir === "l" || dir === "r" ? Math.abs(y) : Math.abs(x)) * 3; if (s < bs) { bs = s; best = e; }
  });
  if (best) foc(best); else if (!top && !inSide && dir === "l") focSide(); // ◀ en el primer póster de la fila: abre el menú lateral
}
function act(el) {
  var a = el.dataset.a, v = el.dataset.v, i = +el.dataset.i;
  if (a === "tab") { S.tab = v; S.cat = "Todas"; render(); foc($('#nav [data-a="tab"][data-v="' + v + '"]')); }
  else if (a === "cat") { S.cat = v; render(); foc($('#chips [data-v="' + v + '"]') || $("#chips .f")); }
  else if (a === "open") openItem(S.items[i]);
  else if (a === "hplay") { var hr = S.hero[S.hi]; askResume(hr, 0, 0, function (at) { playMovie(hr, at); }); }
  else if (a === "hinfo") openItem({ kind: S.tab, rec: S.hero[S.hi] });
  else if (a === "search") openSearch();
  else if (a === "clear") { $("#q").value = ""; doSearch(); }
  else if (a === "scope") { S.ss = v; doSearch(); foc($('#sc [data-v="' + v + '"]')); }
  else if (a === "playm") { var pr = S.cur; askResume(pr, 0, 0, function (at) { playMovie(pr, at); }); }
  else if (a === "season") showSeason(+v);
  else if (a === "ep") { var er = S.cur, ee = eplist(er)[i]; askResume(er, ee.sn, ee.en, function (at) { playEp(er, i, at); }); }
  else if (a === "rsm") { var g1 = S.rgo, at1 = S.rat; closeLayer(); g1(at1); }
  else if (a === "rst") { var g2 = S.rgo; closeLayer(); g2(0); }
  else if (a === "popts") openOpts();
  else if (a === "pclose") closeLayer();
  else if (a === "psub" || a === "paud" || a === "prate" || a === "psync" || a === "pauto") optsDo(a, v);
  else if (a === "rowl" || a === "rowr") { // flechas laterales de cada fila (Magic Remote): avanzan casi una pantalla
    var rw = el.parentNode.querySelector(".rw"), cur = rw._tx != null ? rw._tx : rw.scrollLeft, to = Math.max(0, Math.min(rw.scrollWidth - rw.clientWidth, cur + (a === "rowr" ? 1 : -1) * rw.clientWidth * .8));
    rw._tx = to; tween(rw, "scrollLeft", rw.scrollLeft, to);
  }
  else if (a === "retry") load();
  else if (a === "profile") openWho();
  else if (a === "who") { var wp = findP(v); if (wp) { if (S.manage) openWelcome("edit", v); else enterProfile(wp, false); } }
  else if (a === "newp") openWelcome("new");
  else if (a === "manage") setManage(!S.manage);
  else if (a === "wdel") deleteProfile();
  else if (a === "avatar") pickAvatar(v);
  else if (a === "save") saveProfile();
  else if (a === "wcancel") closeLayer();
  else if (a === "skip") { var m = P.mk, mode = $("#skip").dataset.m; if (mode === "intro") $("#v").currentTime = m.ie; else if (mode === "next") nextEp(); }
}
document.addEventListener("click", function (e) { var el = e.target.closest("[data-a]"); if (el) act(el); });
document.addEventListener("keydown", function (e) {
  var k = e.keyCode, ae = document.activeElement, inp = ae === $("#q") || ae === $("#nm"), top = S.layers[S.layers.length - 1];
  var back = k === 461 || k === 27 || (k === 8 && !inp);
  if (top === "who" && !S.me) { // todavía no se eligió perfil: Atrás sale de la app
    if (k === 461 || k === 27) { e.preventDefault(); window.close(); return; }
    if (k === 8) { e.preventDefault(); return; }
    back = false;
  }
  if (top === "welcome" && S.first) { // primer uso: no hay a dónde volver; Atrás sale de la app (o cierra el teclado)
    if (k === 461 || k === 27) { e.preventDefault(); if (inp) foc($("#wav .av")); else window.close(); return; }
    if (k === 8 && !inp) { e.preventDefault(); return; }
    back = false;
  }
  if (top === "player") {
    e.preventDefault();
    if (back) { if (P.cd) return cancelCd(); return closePlayer(); } // con cuenta regresiva, Atrás solo la cancela
    if (k === 13) { if (P.failed) return retryNow(); if ($("#skip").style.display === "block") return act($("#skip")); ovShow(); return pause(); }
    if (k === 405) return openOpts(); // botón amarillo
    if (k === 406 || k === 73) return toggleStats(); // botón azul (o la tecla I en el navegador): diagnóstico de reproducción
    if (k === 415) { $("#v").play(); return; } if (k === 19) { $("#v").pause(); return; }
    if (k === 37) return seek(-10); if (k === 39) return seek(10); if (k === 412) return seek(-30); if (k === 417) return seek(30);
    if (k === 38 || k === 40) { if (P.ctx && P.ctx.live) return zap(k === 38 ? 1 : -1); if (k === 38) return openOpts(); return ovShow(); }
    return ovShow();
  }
  if (back) { e.preventDefault(); if (!S.layers.length && (S.tab === "movie" || S.tab === "series") && S.cat !== "Todas") { S.cat = "Todas"; render(); focFirst(); return; } if (!closeLayer()) window.close(); return; }
  if (k === 13) { if (inp) return; var d = document.activeElement; if (d && d.dataset && d.dataset.a) { e.preventDefault(); act(d); } return; }
  if (inp && (k === 37 || k === 39)) return;
  var dir = { 37: "l", 38: "u", 39: "r", 40: "d" }[k]; if (dir) { e.preventDefault(); var tn = Date.now(); if (e.repeat && tn - MV.t < 55) return; MV.t = tn; move(dir); }
});
// ---------- Magic Remote (puntero) ----------
// El puntero enfoca lo que señalas y las flechas de cada fila aparecen solo mientras se usa el puntero (las teclas las ocultan).
var PT = { x: -1, y: -1 };
var MV = { t: 0 };
function ptrOff() { document.body.classList.remove("ptr"); SIDE.ptr = false; }
function rowState(rw) { var rr = rw.parentNode, l = rw.scrollLeft <= 2, r = rw.scrollLeft + rw.clientWidth >= rw.scrollWidth - 2; if (rr._a0 !== l) { rr._a0 = l; rr.classList.toggle("a0", l); } if (rr._a1 !== r) { rr._a1 = r; rr.classList.toggle("a1", r); } }
document.addEventListener("mousemove", function (e) {
  if (e.clientX === PT.x && e.clientY === PT.y) return; // el cursor no se movió: lo que se movió fue el contenido bajo él (teclas o scroll); no se toca el foco
  PT.x = e.clientX; PT.y = e.clientY; document.body.classList.add("ptr");
  var top = S.layers[S.layers.length - 1];
  if (top === "player") { ovShow(); return; }
  if (!top) { // menú lateral con el puntero: el borde izquierdo lo abre; al salir de él vuelve a mandar la posición de la lista
    var fs0 = fsz();
    if (e.clientX < 3 * fs0) { SIDE.ptr = true; side(true); } else if (SIDE.ptr && e.clientX > (SW + 1) * fs0) { SIDE.ptr = false; sideAuto(); }
  }
  var el = e.target.closest ? e.target.closest(".f") : null, root = $("#" + (top || "app"));
  if (!el || el === document.activeElement || !root.contains(el)) return;
  kf(el); if (!top) sideNote(el); // solo resalta: no desplaza la lista (evita pelear con la rueda)
});
document.addEventListener("mousedown", function (e) { if (e.target.closest && e.target.closest(".ra")) e.preventDefault(); }); // pulsar una flecha no quita el foco
document.addEventListener("wheel", function () { PT.x = -1; }, true); // tras la rueda, el siguiente movimiento (aunque sea el del sistema) vuelve a resaltar lo que quedó bajo el cursor
document.addEventListener("scroll", function (e) { var t = e.target; if (t.classList && t.classList.contains("rw")) rowState(t); }, true);
document.addEventListener("keydown", ptrOff, true);
document.addEventListener("cursorStateChange", function (e) { if (e.detail && e.detail.visibility === false) ptrOff(); }); // evento de webOS: el puntero se esconde
var qt; $("#q").addEventListener("input", function () { clearTimeout(qt); qt = setTimeout(doSearch, 180); });
// Adapta TODO al tamaño real de la pantalla: 1rem = 1/192 del ancho o 1/108 del alto (el menor)
function fit() {
  var de = document.documentElement, w = window.innerWidth || de.clientWidth || screen.width || 1920, h = window.innerHeight || de.clientHeight || screen.height || 1080;
  de.style.fontSize = Math.max(4, Math.min(w / 192, h / 108)) + "px";
}
window.addEventListener("resize", fit); window.addEventListener("orientationchange", fit); document.addEventListener("DOMContentLoaded", fit);
fit(); [200, 800, 2500].forEach(function (t) { setTimeout(fit, t); });
renderProfile();
if (S.me) prof.setLast(S.me.id);
if (!S.ps.length) openWelcome("first"); // primera vez: pedir nombre y avatar antes de entrar
else if (!S.me) openWho(); // varios perfiles: preguntar quién está viendo
load();

// ---------- 1.0.26: intro animada con sonido, sincronizada y sin tropiezos ----------
// 1) La línea de tiempo CSS (index.html) queda en pausa hasta que el audio EMPIEZA A SONAR ("playing") Y las fuentes están listas (si no, el
//    texto cambiaría de tipografía en pleno movimiento). Si el TV bloquea el audio o algo tarda más de WAIT ms, arranca igual.
// 2) Todo lo que se anima es transform/opacity (lo mueve el compositor, no el hilo principal). El trabajo pesado —leer el catálogo (JSON) y
//    dibujar la rejilla— se hace GATE_MS después de arrancar, con la animación ya en marcha y la app pintada por debajo (invisible),
//    NO al final: así el paso de la intro al catálogo es solo un desvanecimiento, sin congelarse.
// SYNC_MS: la imagen espera este tiempo tras el "playing" para compensar la latencia de salida de audio (≈100–150 ms en un TV).
(function () {
  var el = $("#intro"); if (!el) return;
  var WAIT = 900, SYNC_MS = 120, GATE_MS = 400, started = false, done = false, sndOk = false, fontOk = false, paintOk = false;
  var a = $("#isnd");
  function release() { if (INTRO.done) return; INTRO.done = true; var q = INTRO.q; INTRO.q = []; q.forEach(function (f) { f(); }); }
  function end() {
    if (done) return; done = true;
    window.removeEventListener("keydown", swallow, true);
    document.body.classList.remove("ip"); if (el.parentNode) el.parentNode.removeChild(el);
    release();
  }
  function swallow(e) { var k = e.keyCode; if (k === 461 || k === 27) return; e.preventDefault(); e.stopPropagation(); }
  function go(force) {
    if (started || !(force === true || (sndOk && fontOk && paintOk))) return; started = true;
    setTimeout(function () {
      el.classList.add("go");
      setTimeout(release, GATE_MS); // el catálogo se lee y se dibuja aquí, mientras la intro ya corre
      setTimeout(function () { document.body.classList.remove("ip"); }, 2500); // la app se revela debajo mientras la intro se desvanece (2.85–3.6 s)
      var box = el.querySelector(".ibox");
      var fin = function (e) { if (e.target === box) setTimeout(end, 30); }; // animationend burbujea: solo cuenta el de la salida del propio contenedor
      box.addEventListener("animationend", fin); box.addEventListener("webkitAnimationEnd", fin);
      setTimeout(end, 4600); // seguro por si el evento no llega
    }, SYNC_MS);
  }
  // 1.0.27: no arrancar la línea de tiempo hasta que el primer cuadro de la intro (fondo vacío, igual al splash del sistema) ya se pintó:
  //    si .go se añadía antes del primer pintado, el primer cuadro con la animación ya corriendo tenía que rasterizar todo de golpe y se veía un tirón.
  var raf = window.requestAnimationFrame || window.webkitRequestAnimationFrame || function (f) { setTimeout(f, 34); };
  raf(function () { raf(function () { paintOk = true; go(); }); });
  window.addEventListener("keydown", swallow, true);
  try { // fuentes listas antes de arrancar
    if (document.fonts && document.fonts.load) Promise.all([document.fonts.load("700 20px Fira"), document.fonts.load("400 20px Fira")]).then(function () { fontOk = true; go(); }, function () { fontOk = true; go(); });
    else fontOk = true;
  } catch (e) { fontOk = true; }
  try {
    a.volume = 1; a.addEventListener("playing", function () { sndOk = true; go(); }); a.currentTime = 0;
    var pr = a.play(); if (pr && pr.catch) pr.catch(function () { sndOk = true; go(); });
  } catch (e) { sndOk = true; }
  go();
  setTimeout(function () { go(true); }, WAIT);
})();
